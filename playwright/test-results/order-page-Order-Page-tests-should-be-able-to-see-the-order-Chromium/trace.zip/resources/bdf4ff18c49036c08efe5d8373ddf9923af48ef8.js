import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cart/EmptyCart.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/EmptyCart.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import LinkButton from "/src/ui/LinkButton.jsx";
function EmptyCart() {
  return /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3", children: [
    /* @__PURE__ */ jsxDEV(LinkButton, { to: "/menu", children: "← Back to menu" }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/EmptyCart.jsx",
      lineNumber: 4,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { "data-auto-id": "empty-cart-message", className: "mt-7 font-semibold", children: "Your cart is still empty. Start adding some pizzas :)" }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/EmptyCart.jsx",
      lineNumber: 6,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/EmptyCart.jsx",
    lineNumber: 3,
    columnNumber: 10
  }, this);
}
_c = EmptyCart;
export default EmptyCart;
var _c;
$RefreshReg$(_c, "EmptyCart");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/EmptyCart.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBS007QUFMTixPQUFPQSxvQkFBZ0I7QUFBcUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUU1QyxTQUFTQyxZQUFZO0FBQ25CLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLGFBQ2I7QUFBQSwyQkFBQyxjQUFXLElBQUcsU0FBUSw4QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUEwQztBQUFBLElBRTFDLHVCQUFDLE9BQUUsZ0JBQWEsc0JBQXFCLFdBQVUsc0JBQW9CLHFFQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FNQTtBQUVKO0FBQUNDLEtBVlFEO0FBWVQsZUFBZUE7QUFBVSxJQUFBQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiTGlua0J1dHRvbiIsIkVtcHR5Q2FydCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRW1wdHlDYXJ0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgTGlua0J1dHRvbiBmcm9tICcuLi8uLi91aS9MaW5rQnV0dG9uJztcblxuZnVuY3Rpb24gRW1wdHlDYXJ0KCkge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS0zXCI+XG4gICAgICA8TGlua0J1dHRvbiB0bz1cIi9tZW51XCI+JmxhcnI7IEJhY2sgdG8gbWVudTwvTGlua0J1dHRvbj5cblxuICAgICAgPHAgZGF0YS1hdXRvLWlkPVwiZW1wdHktY2FydC1tZXNzYWdlXCIgY2xhc3NOYW1lPVwibXQtNyBmb250LXNlbWlib2xkXCI+XG4gICAgICAgIFlvdXIgY2FydCBpcyBzdGlsbCBlbXB0eS4gU3RhcnQgYWRkaW5nIHNvbWUgcGl6emFzIDopXG4gICAgICA8L3A+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEVtcHR5Q2FydDtcbiJdLCJmaWxlIjoiL1VzZXJzL2N1c3RvY2FsL0RvY3VtZW50cy9EZXZlbG9wbWVudC9GYXN0LVBpenphLVJlYWN0LUludGVncmF0aW9uLVRlc3RzL3NyYy9mZWF0dXJlcy9jYXJ0L0VtcHR5Q2FydC5qc3gifQ==