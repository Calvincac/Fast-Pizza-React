import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cart/UpdateItemQuantity.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/UpdateItemQuantity.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useDispatch } from "/node_modules/.vite/deps/react-redux.js?v=9f68b94c";
import Button from "/src/ui/Button.jsx";
import { decreaseItemQuantity, increaseItemQuantity } from "/src/features/cart/cartSlice.js";
function UpdateItemQuantity({
  pizzaId,
  currentQuantity
}) {
  _s();
  const dispatch = useDispatch();
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 md:gap-3", children: [
    /* @__PURE__ */ jsxDEV(Button, { "data-auto-id": "decrease-quantity", type: "round", onClick: () => dispatch(decreaseItemQuantity(pizzaId)), children: "-" }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/UpdateItemQuantity.jsx",
      lineNumber: 12,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("span", { "data-auto-id": "current-quantity", className: "text-sm font-medium", children: currentQuantity }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/UpdateItemQuantity.jsx",
      lineNumber: 15,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Button, { "data-auto-id": "increase-quantity", type: "round", onClick: () => dispatch(increaseItemQuantity(pizzaId)), children: "+" }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/UpdateItemQuantity.jsx",
      lineNumber: 16,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/UpdateItemQuantity.jsx",
    lineNumber: 11,
    columnNumber: 10
  }, this);
}
_s(UpdateItemQuantity, "rgTLoBID190wEKCp9+G8W6F7A5M=", false, function() {
  return [useDispatch];
});
_c = UpdateItemQuantity;
export default UpdateItemQuantity;
var _c;
$RefreshReg$(_c, "UpdateItemQuantity");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/UpdateItemQuantity.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU007Ozs7Ozs7Ozs7Ozs7Ozs7QUFUTixTQUFTQSxtQkFBbUI7QUFDNUIsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxzQkFBc0JDLDRCQUE0QjtBQUUzRCxTQUFTQyxtQkFBbUI7QUFBQSxFQUFFQztBQUFBQSxFQUFTQztBQUFnQixHQUFHO0FBQUFDLEtBQUE7QUFDeEQsUUFBTUMsV0FBV1IsWUFBWTtBQUU3QixTQUNFLHVCQUFDLFNBQUksV0FBVSxvQ0FDYjtBQUFBLDJCQUFDLFVBQ0MsZ0JBQWEscUJBQ2IsTUFBSyxTQUNMLFNBQVMsTUFBTVEsU0FBU04scUJBQXFCRyxPQUFPLENBQUMsR0FBRSxpQkFIekQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsSUFDQSx1QkFBQyxVQUFLLGdCQUFhLG9CQUFtQixXQUFVLHVCQUF1QkMsNkJBQXZFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUY7QUFBQSxJQUN2Rix1QkFBQyxVQUNDLGdCQUFhLHFCQUNiLE1BQUssU0FDTCxTQUFTLE1BQU1FLFNBQVNMLHFCQUFxQkUsT0FBTyxDQUFDLEdBQUUsaUJBSHpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLE9BZkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdCQTtBQUVKO0FBQUNFLEdBdEJRSCxvQkFBa0I7QUFBQSxVQUNSSixXQUFXO0FBQUE7QUFBQVMsS0FEckJMO0FBd0JULGVBQWVBO0FBQW1CLElBQUFLO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VEaXNwYXRjaCIsIkJ1dHRvbiIsImRlY3JlYXNlSXRlbVF1YW50aXR5IiwiaW5jcmVhc2VJdGVtUXVhbnRpdHkiLCJVcGRhdGVJdGVtUXVhbnRpdHkiLCJwaXp6YUlkIiwiY3VycmVudFF1YW50aXR5IiwiX3MiLCJkaXNwYXRjaCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVXBkYXRlSXRlbVF1YW50aXR5LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VEaXNwYXRjaCB9IGZyb20gJ3JlYWN0LXJlZHV4JztcbmltcG9ydCBCdXR0b24gZnJvbSAnLi4vLi4vdWkvQnV0dG9uJztcbmltcG9ydCB7IGRlY3JlYXNlSXRlbVF1YW50aXR5LCBpbmNyZWFzZUl0ZW1RdWFudGl0eSB9IGZyb20gJy4vY2FydFNsaWNlJztcblxuZnVuY3Rpb24gVXBkYXRlSXRlbVF1YW50aXR5KHsgcGl6emFJZCwgY3VycmVudFF1YW50aXR5IH0pIHtcbiAgY29uc3QgZGlzcGF0Y2ggPSB1c2VEaXNwYXRjaCgpO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtMiBtZDpnYXAtM1wiPlxuICAgICAgPEJ1dHRvblxuICAgICAgICBkYXRhLWF1dG8taWQ9XCJkZWNyZWFzZS1xdWFudGl0eVwiXG4gICAgICAgIHR5cGU9XCJyb3VuZFwiXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IGRpc3BhdGNoKGRlY3JlYXNlSXRlbVF1YW50aXR5KHBpenphSWQpKX1cbiAgICAgID5cbiAgICAgICAgLVxuICAgICAgPC9CdXR0b24+XG4gICAgICA8c3BhbiBkYXRhLWF1dG8taWQ9XCJjdXJyZW50LXF1YW50aXR5XCIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bVwiPntjdXJyZW50UXVhbnRpdHl9PC9zcGFuPlxuICAgICAgPEJ1dHRvblxuICAgICAgICBkYXRhLWF1dG8taWQ9XCJpbmNyZWFzZS1xdWFudGl0eVwiXG4gICAgICAgIHR5cGU9XCJyb3VuZFwiXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IGRpc3BhdGNoKGluY3JlYXNlSXRlbVF1YW50aXR5KHBpenphSWQpKX1cbiAgICAgID5cbiAgICAgICAgK1xuICAgICAgPC9CdXR0b24+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IFVwZGF0ZUl0ZW1RdWFudGl0eTtcbiJdLCJmaWxlIjoiL1VzZXJzL2N1c3RvY2FsL0RvY3VtZW50cy9EZXZlbG9wbWVudC9GYXN0LVBpenphLVJlYWN0LUludGVncmF0aW9uLVRlc3RzL3NyYy9mZWF0dXJlcy9jYXJ0L1VwZGF0ZUl0ZW1RdWFudGl0eS5qc3gifQ==