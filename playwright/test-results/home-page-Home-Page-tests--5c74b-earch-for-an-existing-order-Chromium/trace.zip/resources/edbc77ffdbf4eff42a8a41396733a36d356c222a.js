import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cart/CartItem.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/CartItem.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useSelector } from "/node_modules/.vite/deps/react-redux.js?v=9f68b94c";
import { formatCurrency } from "/src/utils/helpers.js";
import DeleteItem from "/src/features/cart/DeleteItem.jsx";
import UpdateItemQuantity from "/src/features/cart/UpdateItemQuantity.jsx";
import { getCurrentQuantityById } from "/src/features/cart/cartSlice.js";
function CartItem({
  item
}) {
  _s();
  const {
    pizzaId,
    name,
    quantity,
    totalPrice
  } = item;
  const currentQuantity = useSelector(getCurrentQuantityById(pizzaId));
  return /* @__PURE__ */ jsxDEV("li", { className: "py-3 sm:flex sm:items-center sm:justify-between", children: [
    /* @__PURE__ */ jsxDEV("p", { className: "mb-1 sm:mb-0", children: [
      quantity,
      "× ",
      name
    ] }, void 0, true, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/CartItem.jsx",
      lineNumber: 19,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between sm:gap-6", children: [
      /* @__PURE__ */ jsxDEV("p", { "data-auto-id": "total-price", className: "text-sm font-bold", children: formatCurrency(totalPrice) }, void 0, false, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/CartItem.jsx",
        lineNumber: 23,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(UpdateItemQuantity, { "data-auto-id": "update-cart-item", pizzaId, currentQuantity }, void 0, false, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/CartItem.jsx",
        lineNumber: 25,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(DeleteItem, { "data-auto-id": "delete-cart-item", pizzaId }, void 0, false, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/CartItem.jsx",
        lineNumber: 26,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/CartItem.jsx",
      lineNumber: 22,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/CartItem.jsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
}
_s(CartItem, "3ExAz9P9La7JqeMrHrqRPX1Hp98=", false, function() {
  return [useSelector];
});
_c = CartItem;
export default CartItem;
var _c;
$RefreshReg$(_c, "CartItem");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/CartItem.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBYU07Ozs7Ozs7Ozs7Ozs7Ozs7QUFiTixTQUFTQSxtQkFBbUI7QUFDNUIsU0FBU0Msc0JBQXNCO0FBQy9CLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyx3QkFBd0I7QUFDL0IsU0FBU0MsOEJBQThCO0FBRXZDLFNBQVNDLFNBQVM7QUFBQSxFQUFFQztBQUFLLEdBQUc7QUFBQUMsS0FBQTtBQUMxQixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBU0M7QUFBQUEsSUFBTUM7QUFBQUEsSUFBVUM7QUFBQUEsRUFBVyxJQUFJTDtBQUVoRCxRQUFNTSxrQkFBa0JaLFlBQVlJLHVCQUF1QkksT0FBTyxDQUFDO0FBRW5FLFNBQ0UsdUJBQUMsUUFBRyxXQUFVLG1EQUNaO0FBQUEsMkJBQUMsT0FBRSxXQUFVLGdCQUNWRTtBQUFBQTtBQUFBQSxNQUFTO0FBQUEsTUFBU0Q7QUFBQUEsU0FEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxTQUFJLFdBQVUsOENBQ2I7QUFBQSw2QkFBQyxPQUFFLGdCQUFhLGVBQWMsV0FBVSxxQkFBcUJSLHlCQUFlVSxVQUFVLEtBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBd0Y7QUFBQSxNQUV4Rix1QkFBQyxzQkFDQyxnQkFBYSxvQkFDYixTQUNBLG1CQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFHbUM7QUFBQSxNQUVuQyx1QkFBQyxjQUFXLGdCQUFhLG9CQUFtQixXQUE1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTZEO0FBQUEsU0FSL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVNBO0FBQUEsT0FiRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBY0E7QUFFSjtBQUFDSixHQXRCUUYsVUFBUTtBQUFBLFVBR1NMLFdBQVc7QUFBQTtBQUFBYSxLQUg1QlI7QUF3QlQsZUFBZUE7QUFBUyxJQUFBUTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU2VsZWN0b3IiLCJmb3JtYXRDdXJyZW5jeSIsIkRlbGV0ZUl0ZW0iLCJVcGRhdGVJdGVtUXVhbnRpdHkiLCJnZXRDdXJyZW50UXVhbnRpdHlCeUlkIiwiQ2FydEl0ZW0iLCJpdGVtIiwiX3MiLCJwaXp6YUlkIiwibmFtZSIsInF1YW50aXR5IiwidG90YWxQcmljZSIsImN1cnJlbnRRdWFudGl0eSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ2FydEl0ZW0uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVNlbGVjdG9yIH0gZnJvbSAncmVhY3QtcmVkdXgnO1xuaW1wb3J0IHsgZm9ybWF0Q3VycmVuY3kgfSBmcm9tICcuLi8uLi91dGlscy9oZWxwZXJzJztcbmltcG9ydCBEZWxldGVJdGVtIGZyb20gJy4vRGVsZXRlSXRlbSc7XG5pbXBvcnQgVXBkYXRlSXRlbVF1YW50aXR5IGZyb20gJy4vVXBkYXRlSXRlbVF1YW50aXR5JztcbmltcG9ydCB7IGdldEN1cnJlbnRRdWFudGl0eUJ5SWQgfSBmcm9tICcuL2NhcnRTbGljZSc7XG5cbmZ1bmN0aW9uIENhcnRJdGVtKHsgaXRlbSB9KSB7XG4gIGNvbnN0IHsgcGl6emFJZCwgbmFtZSwgcXVhbnRpdHksIHRvdGFsUHJpY2UgfSA9IGl0ZW07XG5cbiAgY29uc3QgY3VycmVudFF1YW50aXR5ID0gdXNlU2VsZWN0b3IoZ2V0Q3VycmVudFF1YW50aXR5QnlJZChwaXp6YUlkKSk7XG5cbiAgcmV0dXJuIChcbiAgICA8bGkgY2xhc3NOYW1lPVwicHktMyBzbTpmbGV4IHNtOml0ZW1zLWNlbnRlciBzbTpqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgIDxwIGNsYXNzTmFtZT1cIm1iLTEgc206bWItMFwiPlxuICAgICAgICB7cXVhbnRpdHl9JnRpbWVzOyB7bmFtZX1cbiAgICAgIDwvcD5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIHNtOmdhcC02XCI+XG4gICAgICAgIDxwIGRhdGEtYXV0by1pZD1cInRvdGFsLXByaWNlXCIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LWJvbGRcIj57Zm9ybWF0Q3VycmVuY3kodG90YWxQcmljZSl9PC9wPlxuXG4gICAgICAgIDxVcGRhdGVJdGVtUXVhbnRpdHlcbiAgICAgICAgICBkYXRhLWF1dG8taWQ9XCJ1cGRhdGUtY2FydC1pdGVtXCJcbiAgICAgICAgICBwaXp6YUlkPXtwaXp6YUlkfVxuICAgICAgICAgIGN1cnJlbnRRdWFudGl0eT17Y3VycmVudFF1YW50aXR5fVxuICAgICAgICAvPlxuICAgICAgICA8RGVsZXRlSXRlbSBkYXRhLWF1dG8taWQ9XCJkZWxldGUtY2FydC1pdGVtXCIgcGl6emFJZD17cGl6emFJZH0gLz5cbiAgICAgIDwvZGl2PlxuICAgIDwvbGk+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IENhcnRJdGVtO1xuIl0sImZpbGUiOiIvVXNlcnMvY3VzdG9jYWwvRG9jdW1lbnRzL0RldmVsb3BtZW50L0Zhc3QtUGl6emEtUmVhY3QtSW50ZWdyYXRpb24tVGVzdHMvc3JjL2ZlYXR1cmVzL2NhcnQvQ2FydEl0ZW0uanN4In0=