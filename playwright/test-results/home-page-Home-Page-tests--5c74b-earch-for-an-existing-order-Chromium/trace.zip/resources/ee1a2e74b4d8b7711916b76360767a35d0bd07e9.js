import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cart/CartOverview.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/CartOverview.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useSelector } from "/node_modules/.vite/deps/react-redux.js?v=9f68b94c";
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=9f68b94c";
import { getTotalCartPrice, getTotalCartQuantity } from "/src/features/cart/cartSlice.js";
import { formatCurrency } from "/src/utils/helpers.js";
function CartOverview() {
  _s();
  const totalCartQuantity = useSelector(getTotalCartQuantity);
  const totalCartPrice = useSelector(getTotalCartPrice);
  if (!totalCartQuantity)
    return null;
  return /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between bg-stone-800 px-4 py-4 text-sm uppercase text-stone-200 sm:px-6 md:text-base", children: [
    /* @__PURE__ */ jsxDEV("p", { className: "space-x-4 font-semibold text-stone-300 sm:space-x-6", children: [
      /* @__PURE__ */ jsxDEV("span", { "data-auto-id": "cart-quantity", children: [
        totalCartQuantity,
        " pizzas"
      ] }, void 0, true, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/CartOverview.jsx",
        lineNumber: 13,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { "data-auto-id": "total-cart-price", children: formatCurrency(totalCartPrice) }, void 0, false, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/CartOverview.jsx",
        lineNumber: 14,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/CartOverview.jsx",
      lineNumber: 12,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Link, { "data-auto-id": "open-cart-button", to: "/cart", children: "Open cart →" }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/CartOverview.jsx",
      lineNumber: 16,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/CartOverview.jsx",
    lineNumber: 11,
    columnNumber: 10
  }, this);
}
_s(CartOverview, "Hxq5OfTSH83gWD9koMkMSLN4nJ0=", false, function() {
  return [useSelector, useSelector];
});
_c = CartOverview;
export default CartOverview;
var _c;
$RefreshReg$(_c, "CartOverview");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/CartOverview.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBY1E7Ozs7Ozs7Ozs7Ozs7Ozs7QUFkUixTQUFTQSxtQkFBbUI7QUFDNUIsU0FBU0MsWUFBWTtBQUNyQixTQUFTQyxtQkFBbUJDLDRCQUE0QjtBQUN4RCxTQUFTQyxzQkFBc0I7QUFFL0IsU0FBU0MsZUFBZTtBQUFBQyxLQUFBO0FBQ3RCLFFBQU1DLG9CQUFvQlAsWUFBWUcsb0JBQW9CO0FBQzFELFFBQU1LLGlCQUFpQlIsWUFBWUUsaUJBQWlCO0FBRXBELE1BQUksQ0FBQ0s7QUFBbUIsV0FBTztBQUUvQixTQUNFLHVCQUFDLFNBQUksV0FBVSxrSEFDYjtBQUFBLDJCQUFDLE9BQUUsV0FBVSx1REFDWDtBQUFBLDZCQUFDLFVBQUssZ0JBQWEsaUJBQWtCQTtBQUFBQTtBQUFBQSxRQUFrQjtBQUFBLFdBQXZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBOEQ7QUFBQSxNQUM5RCx1QkFBQyxVQUFLLGdCQUFhLG9CQUFxQkgseUJBQWVJLGNBQWMsS0FBckU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUF1RTtBQUFBLFNBRnpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FHQTtBQUFBLElBQ0EsdUJBQUMsUUFBSyxnQkFBYSxvQkFBbUIsSUFBRyxTQUFRLDJCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWlFO0FBQUEsT0FMbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQU1BO0FBRUo7QUFBQ0YsR0FmUUQsY0FBWTtBQUFBLFVBQ09MLGFBQ0hBLFdBQVc7QUFBQTtBQUFBUyxLQUYzQko7QUFpQlQsZUFBZUE7QUFBYSxJQUFBSTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU2VsZWN0b3IiLCJMaW5rIiwiZ2V0VG90YWxDYXJ0UHJpY2UiLCJnZXRUb3RhbENhcnRRdWFudGl0eSIsImZvcm1hdEN1cnJlbmN5IiwiQ2FydE92ZXJ2aWV3IiwiX3MiLCJ0b3RhbENhcnRRdWFudGl0eSIsInRvdGFsQ2FydFByaWNlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDYXJ0T3ZlcnZpZXcuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVNlbGVjdG9yIH0gZnJvbSAncmVhY3QtcmVkdXgnO1xuaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IHsgZ2V0VG90YWxDYXJ0UHJpY2UsIGdldFRvdGFsQ2FydFF1YW50aXR5IH0gZnJvbSAnLi9jYXJ0U2xpY2UnO1xuaW1wb3J0IHsgZm9ybWF0Q3VycmVuY3kgfSBmcm9tICcuLi8uLi91dGlscy9oZWxwZXJzJztcblxuZnVuY3Rpb24gQ2FydE92ZXJ2aWV3KCkge1xuICBjb25zdCB0b3RhbENhcnRRdWFudGl0eSA9IHVzZVNlbGVjdG9yKGdldFRvdGFsQ2FydFF1YW50aXR5KTtcbiAgY29uc3QgdG90YWxDYXJ0UHJpY2UgPSB1c2VTZWxlY3RvcihnZXRUb3RhbENhcnRQcmljZSk7XG5cbiAgaWYgKCF0b3RhbENhcnRRdWFudGl0eSkgcmV0dXJuIG51bGw7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBiZy1zdG9uZS04MDAgcHgtNCBweS00IHRleHQtc20gdXBwZXJjYXNlIHRleHQtc3RvbmUtMjAwIHNtOnB4LTYgbWQ6dGV4dC1iYXNlXCI+XG4gICAgICA8cCBjbGFzc05hbWU9XCJzcGFjZS14LTQgZm9udC1zZW1pYm9sZCB0ZXh0LXN0b25lLTMwMCBzbTpzcGFjZS14LTZcIj5cbiAgICAgICAgPHNwYW4gZGF0YS1hdXRvLWlkPVwiY2FydC1xdWFudGl0eVwiID57dG90YWxDYXJ0UXVhbnRpdHl9IHBpenphczwvc3Bhbj5cbiAgICAgICAgPHNwYW4gZGF0YS1hdXRvLWlkPVwidG90YWwtY2FydC1wcmljZVwiID57Zm9ybWF0Q3VycmVuY3kodG90YWxDYXJ0UHJpY2UpfTwvc3Bhbj5cbiAgICAgIDwvcD5cbiAgICAgIDxMaW5rIGRhdGEtYXV0by1pZD1cIm9wZW4tY2FydC1idXR0b25cIiB0bz1cIi9jYXJ0XCI+T3BlbiBjYXJ0ICZyYXJyOzwvTGluaz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQ2FydE92ZXJ2aWV3O1xuIl0sImZpbGUiOiIvVXNlcnMvY3VzdG9jYWwvRG9jdW1lbnRzL0RldmVsb3BtZW50L0Zhc3QtUGl6emEtUmVhY3QtSW50ZWdyYXRpb24tVGVzdHMvc3JjL2ZlYXR1cmVzL2NhcnQvQ2FydE92ZXJ2aWV3LmpzeCJ9