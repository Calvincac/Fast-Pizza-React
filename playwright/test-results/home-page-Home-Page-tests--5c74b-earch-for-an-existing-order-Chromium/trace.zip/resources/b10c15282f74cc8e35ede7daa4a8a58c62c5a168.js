import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/menu/Menu.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/Menu.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useLoaderData } from "/node_modules/.vite/deps/react-router-dom.js?v=9f68b94c";
import { getMenu } from "/src/services/apiRestaurant.js";
import MenuItem from "/src/features/menu/MenuItem.jsx";
function Menu() {
  _s();
  const menu = useLoaderData();
  return /* @__PURE__ */ jsxDEV("ul", { className: "divide-y divide-stone-200 px-2", children: menu.map((pizza) => /* @__PURE__ */ jsxDEV(MenuItem, { pizza }, pizza.id, false, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/Menu.jsx",
    lineNumber: 9,
    columnNumber: 26
  }, this)) }, void 0, false, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/Menu.jsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
}
_s(Menu, "bOhDkyZM9ac2/vpinsvI4DKoadc=", false, function() {
  return [useLoaderData];
});
_c = Menu;
export async function loader() {
  const menu = await getMenu();
  return menu;
}
export default Menu;
var _c;
$RefreshReg$(_c, "Menu");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/Menu.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVVE7Ozs7Ozs7Ozs7Ozs7Ozs7QUFWUixTQUFTQSxxQkFBcUI7QUFDOUIsU0FBU0MsZUFBZTtBQUN4QixPQUFPQyxjQUFjO0FBRXJCLFNBQVNDLE9BQU87QUFBQUMsS0FBQTtBQUNkLFFBQU1DLE9BQU9MLGNBQWM7QUFFM0IsU0FDRSx1QkFBQyxRQUFHLFdBQVUsa0NBQ1hLLGVBQUtDLElBQUtDLFdBQ1QsdUJBQUMsWUFBUyxTQUFtQkEsTUFBTUMsSUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFzQyxDQUN2QyxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FJQTtBQUVKO0FBQUNKLEdBVlFELE1BQUk7QUFBQSxVQUNFSCxhQUFhO0FBQUE7QUFBQVMsS0FEbkJOO0FBWVQsc0JBQXNCTyxTQUFTO0FBQzdCLFFBQU1MLE9BQU8sTUFBTUosUUFBUTtBQUMzQixTQUFPSTtBQUNUO0FBRUEsZUFBZUY7QUFBSyxJQUFBTTtBQUFBRSxhQUFBRixJQUFBIiwibmFtZXMiOlsidXNlTG9hZGVyRGF0YSIsImdldE1lbnUiLCJNZW51SXRlbSIsIk1lbnUiLCJfcyIsIm1lbnUiLCJtYXAiLCJwaXp6YSIsImlkIiwiX2MiLCJsb2FkZXIiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJNZW51LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VMb2FkZXJEYXRhIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgeyBnZXRNZW51IH0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpUmVzdGF1cmFudCc7XG5pbXBvcnQgTWVudUl0ZW0gZnJvbSAnLi9NZW51SXRlbSc7XG5cbmZ1bmN0aW9uIE1lbnUoKSB7XG4gIGNvbnN0IG1lbnUgPSB1c2VMb2FkZXJEYXRhKCk7XG5cbiAgcmV0dXJuIChcbiAgICA8dWwgY2xhc3NOYW1lPVwiZGl2aWRlLXkgZGl2aWRlLXN0b25lLTIwMCBweC0yXCI+XG4gICAgICB7bWVudS5tYXAoKHBpenphKSA9PiAoXG4gICAgICAgIDxNZW51SXRlbSBwaXp6YT17cGl6emF9IGtleT17cGl6emEuaWR9IC8+XG4gICAgICApKX1cbiAgICA8L3VsPlxuICApO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbG9hZGVyKCkge1xuICBjb25zdCBtZW51ID0gYXdhaXQgZ2V0TWVudSgpO1xuICByZXR1cm4gbWVudTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgTWVudTtcbiJdLCJmaWxlIjoiL1VzZXJzL2N1c3RvY2FsL0RvY3VtZW50cy9EZXZlbG9wbWVudC9GYXN0LVBpenphLVJlYWN0LUludGVncmF0aW9uLVRlc3RzL3NyYy9mZWF0dXJlcy9tZW51L01lbnUuanN4In0=