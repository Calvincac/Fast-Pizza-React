import { configureStore } from "/node_modules/.vite/deps/@reduxjs_toolkit.js?v=9f68b94c";
import userReducer from "/src/features/user/userSlice.js";
import cartReducer from "/src/features/cart/cartSlice.js";

const store = configureStore({
  reducer: {
    user: userReducer,
    cart: cartReducer,
  },
});

export default store;
