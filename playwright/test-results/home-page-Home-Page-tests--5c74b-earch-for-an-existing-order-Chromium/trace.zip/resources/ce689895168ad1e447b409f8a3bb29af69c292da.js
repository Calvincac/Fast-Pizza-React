import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/LinkButton.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/LinkButton.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { Link, useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9f68b94c";
function LinkButton({
  children,
  to
}) {
  _s();
  const navigate = useNavigate();
  const className = "text-sm text-blue-500 hover:text-blue-600 hover:underline";
  if (to === "-1")
    return /* @__PURE__ */ jsxDEV("button", { className, onClick: () => navigate(-1), children }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/LinkButton.jsx",
      lineNumber: 10,
      columnNumber: 27
    }, this);
  return /* @__PURE__ */ jsxDEV(Link, { to, className, children }, void 0, false, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/LinkButton.jsx",
    lineNumber: 13,
    columnNumber: 10
  }, this);
}
_s(LinkButton, "CzcTeTziyjMsSrAVmHuCCb6+Bfg=", false, function() {
  return [useNavigate];
});
_c = LinkButton;
export default LinkButton;
var _c;
$RefreshReg$(_c, "LinkButton");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/LinkButton.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUU07Ozs7Ozs7Ozs7Ozs7Ozs7QUFSTixTQUFTQSxNQUFNQyxtQkFBbUI7QUFFbEMsU0FBU0MsV0FBVztBQUFBLEVBQUVDO0FBQUFBLEVBQVVDO0FBQUcsR0FBRztBQUFBQyxLQUFBO0FBQ3BDLFFBQU1DLFdBQVdMLFlBQVk7QUFDN0IsUUFBTU0sWUFBWTtBQUVsQixNQUFJSCxPQUFPO0FBQ1QsV0FDRSx1QkFBQyxZQUFPLFdBQXNCLFNBQVMsTUFBTUUsU0FBUyxFQUFFLEdBQ3JESCxZQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUdKLFNBQ0UsdUJBQUMsUUFBSyxJQUFRLFdBQ1hBLFlBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUo7QUFBQ0UsR0FoQlFILFlBQVU7QUFBQSxVQUNBRCxXQUFXO0FBQUE7QUFBQU8sS0FEckJOO0FBa0JULGVBQWVBO0FBQVcsSUFBQU07QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkxpbmsiLCJ1c2VOYXZpZ2F0ZSIsIkxpbmtCdXR0b24iLCJjaGlsZHJlbiIsInRvIiwiX3MiLCJuYXZpZ2F0ZSIsImNsYXNzTmFtZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTGlua0J1dHRvbi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluaywgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcblxuZnVuY3Rpb24gTGlua0J1dHRvbih7IGNoaWxkcmVuLCB0byB9KSB7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcbiAgY29uc3QgY2xhc3NOYW1lID0gJ3RleHQtc20gdGV4dC1ibHVlLTUwMCBob3Zlcjp0ZXh0LWJsdWUtNjAwIGhvdmVyOnVuZGVybGluZSc7XG5cbiAgaWYgKHRvID09PSAnLTEnKVxuICAgIHJldHVybiAoXG4gICAgICA8YnV0dG9uIGNsYXNzTmFtZT17Y2xhc3NOYW1lfSBvbkNsaWNrPXsoKSA9PiBuYXZpZ2F0ZSgtMSl9PlxuICAgICAgICB7Y2hpbGRyZW59XG4gICAgICA8L2J1dHRvbj5cbiAgICApO1xuXG4gIHJldHVybiAoXG4gICAgPExpbmsgdG89e3RvfSBjbGFzc05hbWU9e2NsYXNzTmFtZX0+XG4gICAgICB7Y2hpbGRyZW59XG4gICAgPC9MaW5rPlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBMaW5rQnV0dG9uO1xuIl0sImZpbGUiOiIvVXNlcnMvY3VzdG9jYWwvRG9jdW1lbnRzL0RldmVsb3BtZW50L0Zhc3QtUGl6emEtUmVhY3QtSW50ZWdyYXRpb24tVGVzdHMvc3JjL3VpL0xpbmtCdXR0b24uanN4In0=