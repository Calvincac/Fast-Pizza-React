import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/Home.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Home.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useSelector } from "/node_modules/.vite/deps/react-redux.js?v=9f68b94c";
import CreateUser from "/src/features/user/CreateUser.jsx?t=1726415986978";
import Button from "/src/ui/Button.jsx";
function Home() {
  _s();
  const username = useSelector((state) => state.user.username);
  return /* @__PURE__ */ jsxDEV("div", { className: "my-10 px-4 text-center sm:my-16", children: [
    /* @__PURE__ */ jsxDEV("h1", { className: "mb-8  text-xl font-semibold md:text-3xl", children: [
      "The best pizza.",
      /* @__PURE__ */ jsxDEV("br", {}, void 0, false, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Home.jsx",
        lineNumber: 11,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("span", { className: "text-yellow-500", children: "Straight out of the oven, straight to you." }, void 0, false, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Home.jsx",
        lineNumber: 12,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Home.jsx",
      lineNumber: 9,
      columnNumber: 7
    }, this),
    username === "" ? /* @__PURE__ */ jsxDEV(CreateUser, {}, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Home.jsx",
      lineNumber: 17,
      columnNumber: 26
    }, this) : /* @__PURE__ */ jsxDEV(Button, { to: "/menu", type: "primary", children: [
      "Continue ordering, ",
      username
    ] }, void 0, true, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Home.jsx",
      lineNumber: 17,
      columnNumber: 43
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Home.jsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
}
_s(Home, "Hd4PBq58Xc1y9+EldUXenW1lAB0=", false, function() {
  return [useSelector];
});
_c = Home;
export default Home;
var _c;
$RefreshReg$(_c, "Home");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Home.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV1E7Ozs7Ozs7Ozs7Ozs7Ozs7QUFYUixTQUFTQSxtQkFBbUI7QUFDNUIsT0FBT0MsZ0JBQWdCO0FBQ3ZCLE9BQU9DLFlBQVk7QUFFbkIsU0FBU0MsT0FBTztBQUFBQyxLQUFBO0FBQ2QsUUFBTUMsV0FBV0wsWUFBYU0sV0FBVUEsTUFBTUMsS0FBS0YsUUFBUTtBQUUzRCxTQUNFLHVCQUFDLFNBQUksV0FBVSxtQ0FDYjtBQUFBLDJCQUFDLFFBQUcsV0FBVSwyQ0FBeUM7QUFBQTtBQUFBLE1BRXJELHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFHO0FBQUEsTUFDSCx1QkFBQyxVQUFLLFdBQVUsbUJBQWlCLDBEQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FNQTtBQUFBLElBRUNBLGFBQWEsS0FDWix1QkFBQyxnQkFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQVcsSUFFWCx1QkFBQyxVQUFPLElBQUcsU0FBUSxNQUFLLFdBQVM7QUFBQTtBQUFBLE1BQ1hBO0FBQUFBLFNBRHRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FFQTtBQUFBLE9BZEo7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdCQTtBQUVKO0FBQUNELEdBdEJRRCxNQUFJO0FBQUEsVUFDTUgsV0FBVztBQUFBO0FBQUFRLEtBRHJCTDtBQXdCVCxlQUFlQTtBQUFLLElBQUFLO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTZWxlY3RvciIsIkNyZWF0ZVVzZXIiLCJCdXR0b24iLCJIb21lIiwiX3MiLCJ1c2VybmFtZSIsInN0YXRlIiwidXNlciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiSG9tZS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU2VsZWN0b3IgfSBmcm9tICdyZWFjdC1yZWR1eCc7XG5pbXBvcnQgQ3JlYXRlVXNlciBmcm9tICcuLi9mZWF0dXJlcy91c2VyL0NyZWF0ZVVzZXInO1xuaW1wb3J0IEJ1dHRvbiBmcm9tICcuL0J1dHRvbic7XG5cbmZ1bmN0aW9uIEhvbWUoKSB7XG4gIGNvbnN0IHVzZXJuYW1lID0gdXNlU2VsZWN0b3IoKHN0YXRlKSA9PiBzdGF0ZS51c2VyLnVzZXJuYW1lKTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwibXktMTAgcHgtNCB0ZXh0LWNlbnRlciBzbTpteS0xNlwiPlxuICAgICAgPGgxIGNsYXNzTmFtZT1cIm1iLTggIHRleHQteGwgZm9udC1zZW1pYm9sZCBtZDp0ZXh0LTN4bFwiPlxuICAgICAgICBUaGUgYmVzdCBwaXp6YS5cbiAgICAgICAgPGJyIC8+XG4gICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQteWVsbG93LTUwMFwiPlxuICAgICAgICAgIFN0cmFpZ2h0IG91dCBvZiB0aGUgb3Zlbiwgc3RyYWlnaHQgdG8geW91LlxuICAgICAgICA8L3NwYW4+XG4gICAgICA8L2gxPlxuXG4gICAgICB7dXNlcm5hbWUgPT09ICcnID8gKFxuICAgICAgICA8Q3JlYXRlVXNlciAvPlxuICAgICAgKSA6IChcbiAgICAgICAgPEJ1dHRvbiB0bz1cIi9tZW51XCIgdHlwZT1cInByaW1hcnlcIj5cbiAgICAgICAgICBDb250aW51ZSBvcmRlcmluZywge3VzZXJuYW1lfVxuICAgICAgICA8L0J1dHRvbj5cbiAgICAgICl9XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEhvbWU7XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jdXN0b2NhbC9Eb2N1bWVudHMvRGV2ZWxvcG1lbnQvRmFzdC1QaXp6YS1SZWFjdC1JbnRlZ3JhdGlvbi1UZXN0cy9zcmMvdWkvSG9tZS5qc3gifQ==