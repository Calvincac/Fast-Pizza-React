import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/user/CreateUser.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/user/CreateUser.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f68b94c"; const useState = __vite__cjsImport3_react["useState"];
import Button from "/src/ui/Button.jsx";
import { useDispatch } from "/node_modules/.vite/deps/react-redux.js?v=9f68b94c";
import { updateName } from "/src/features/user/userSlice.js";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9f68b94c";
function CreateUser() {
  _s();
  const [username, setUsername] = useState("");
  const dispatch = useDispatch();
  const navigate = useNavigate();
  function handleSubmit(e) {
    e.preventDefault();
    if (!username)
      return;
    dispatch(updateName(username));
    navigate("/menu");
  }
  return /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: [
    /* @__PURE__ */ jsxDEV("p", { className: "mb-4 text-sm text-stone-600 md:text-base", "data-auto-id": "welcome-message", children: "👋 Welcome! Please start by telling us your name:" }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/user/CreateUser.jsx",
      lineNumber: 19,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("input", { "data-auto-id": "username", type: "text", placeholder: "Your full name", value: username, onChange: (e) => setUsername(e.target.value), className: "input mb-8 w-72" }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/user/CreateUser.jsx",
      lineNumber: 23,
      columnNumber: 7
    }, this),
    username !== "" && /* @__PURE__ */ jsxDEV("div", { "data-auto-id": "start-order", children: /* @__PURE__ */ jsxDEV(Button, { type: "primary", children: "Start ordering" }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/user/CreateUser.jsx",
      lineNumber: 26,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/user/CreateUser.jsx",
      lineNumber: 25,
      columnNumber: 27
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/user/CreateUser.jsx",
    lineNumber: 18,
    columnNumber: 10
  }, this);
}
_s(CreateUser, "1CXMKp9fU/vpKrCC8TCBwTCo4/0=", false, function() {
  return [useDispatch, useNavigate];
});
_c = CreateUser;
export default CreateUser;
var _c;
$RefreshReg$(_c, "CreateUser");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/user/CreateUser.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJNOzs7Ozs7Ozs7Ozs7Ozs7O0FBckJOLFNBQVNBLGdCQUFnQjtBQUN6QixPQUFPQyxZQUFZO0FBQ25CLFNBQVNDLG1CQUFtQjtBQUM1QixTQUFTQyxrQkFBa0I7QUFDM0IsU0FBU0MsbUJBQW1CO0FBRTVCLFNBQVNDLGFBQWE7QUFBQUMsS0FBQTtBQUNwQixRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSVIsU0FBUyxFQUFFO0FBQzNDLFFBQU1TLFdBQVdQLFlBQVk7QUFDN0IsUUFBTVEsV0FBV04sWUFBWTtBQUU3QixXQUFTTyxhQUFhQyxHQUFHO0FBQ3ZCQSxNQUFFQyxlQUFlO0FBRWpCLFFBQUksQ0FBQ047QUFBVTtBQUNmRSxhQUFTTixXQUFXSSxRQUFRLENBQUM7QUFDN0JHLGFBQVMsT0FBTztBQUFBLEVBQ2xCO0FBRUEsU0FDRSx1QkFBQyxVQUFLLFVBQVVDLGNBQ2Q7QUFBQSwyQkFBQyxPQUFFLFdBQVUsNENBQTJDLGdCQUFhLG1CQUFpQixpRUFBdEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFFQSx1QkFBQyxXQUNDLGdCQUFhLFlBQ2IsTUFBSyxRQUNMLGFBQVksa0JBQ1osT0FBT0osVUFDUCxVQUFXSyxPQUFNSixZQUFZSSxFQUFFRSxPQUFPQyxLQUFLLEdBQzNDLFdBQVUscUJBTlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU02QjtBQUFBLElBRzVCUixhQUFhLE1BQ1osdUJBQUMsU0FBSSxnQkFBYSxlQUNoQixpQ0FBQyxVQUFPLE1BQUssV0FBVSw4QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxQyxLQUR2QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQWpCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBbUJBO0FBRUo7QUFBQ0QsR0FuQ1FELFlBQVU7QUFBQSxVQUVBSCxhQUNBRSxXQUFXO0FBQUE7QUFBQVksS0FIckJYO0FBcUNULGVBQWVBO0FBQVcsSUFBQVc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiQnV0dG9uIiwidXNlRGlzcGF0Y2giLCJ1cGRhdGVOYW1lIiwidXNlTmF2aWdhdGUiLCJDcmVhdGVVc2VyIiwiX3MiLCJ1c2VybmFtZSIsInNldFVzZXJuYW1lIiwiZGlzcGF0Y2giLCJuYXZpZ2F0ZSIsImhhbmRsZVN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInRhcmdldCIsInZhbHVlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDcmVhdGVVc2VyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0JztcbmltcG9ydCBCdXR0b24gZnJvbSAnLi4vLi4vdWkvQnV0dG9uJztcbmltcG9ydCB7IHVzZURpc3BhdGNoIH0gZnJvbSAncmVhY3QtcmVkdXgnO1xuaW1wb3J0IHsgdXBkYXRlTmFtZSB9IGZyb20gJy4vdXNlclNsaWNlJztcbmltcG9ydCB7IHVzZU5hdmlnYXRlIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5cbmZ1bmN0aW9uIENyZWF0ZVVzZXIoKSB7XG4gIGNvbnN0IFt1c2VybmFtZSwgc2V0VXNlcm5hbWVdID0gdXNlU3RhdGUoJycpO1xuICBjb25zdCBkaXNwYXRjaCA9IHVzZURpc3BhdGNoKCk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcblxuICBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoZSkge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcblxuICAgIGlmICghdXNlcm5hbWUpIHJldHVybjtcbiAgICBkaXNwYXRjaCh1cGRhdGVOYW1lKHVzZXJuYW1lKSk7XG4gICAgbmF2aWdhdGUoJy9tZW51Jyk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxmb3JtIG9uU3VibWl0PXtoYW5kbGVTdWJtaXR9PlxuICAgICAgPHAgY2xhc3NOYW1lPVwibWItNCB0ZXh0LXNtIHRleHQtc3RvbmUtNjAwIG1kOnRleHQtYmFzZVwiIGRhdGEtYXV0by1pZD1cIndlbGNvbWUtbWVzc2FnZVwiPlxuICAgICAgICDwn5GLIFdlbGNvbWUhIFBsZWFzZSBzdGFydCBieSB0ZWxsaW5nIHVzIHlvdXIgbmFtZTpcbiAgICAgIDwvcD5cblxuICAgICAgPGlucHV0XG4gICAgICAgIGRhdGEtYXV0by1pZD1cInVzZXJuYW1lXCJcbiAgICAgICAgdHlwZT1cInRleHRcIlxuICAgICAgICBwbGFjZWhvbGRlcj1cIllvdXIgZnVsbCBuYW1lXCJcbiAgICAgICAgdmFsdWU9e3VzZXJuYW1lfVxuICAgICAgICBvbkNoYW5nZT17KGUpID0+IHNldFVzZXJuYW1lKGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgY2xhc3NOYW1lPVwiaW5wdXQgbWItOCB3LTcyXCJcbiAgICAgIC8+XG5cbiAgICAgIHt1c2VybmFtZSAhPT0gJycgJiYgKFxuICAgICAgICA8ZGl2IGRhdGEtYXV0by1pZD1cInN0YXJ0LW9yZGVyXCI+XG4gICAgICAgICAgPEJ1dHRvbiB0eXBlPVwicHJpbWFyeVwiPlN0YXJ0IG9yZGVyaW5nPC9CdXR0b24+XG4gICAgICAgIDwvZGl2PlxuICAgICAgKX1cbiAgICA8L2Zvcm0+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IENyZWF0ZVVzZXI7XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jdXN0b2NhbC9Eb2N1bWVudHMvRGV2ZWxvcG1lbnQvRmFzdC1QaXp6YS1SZWFjdC1JbnRlZ3JhdGlvbi1UZXN0cy9zcmMvZmVhdHVyZXMvdXNlci9DcmVhdGVVc2VyLmpzeCJ9