import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/order/OrderItem.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/OrderItem.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { formatCurrency } from "/src/utils/helpers.js";
function OrderItem({
  item,
  isLoadingIngredients,
  ingredients
}) {
  const {
    quantity,
    name,
    totalPrice
  } = item;
  return /* @__PURE__ */ jsxDEV("li", { className: "space-y-1 py-3", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between gap-4 text-sm", children: [
      /* @__PURE__ */ jsxDEV("p", { children: [
        /* @__PURE__ */ jsxDEV("span", { "data-auto-id": "item-quantity", className: "font-bold", children: [
          quantity,
          "×"
        ] }, void 0, true, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/OrderItem.jsx",
          lineNumber: 15,
          columnNumber: 11
        }, this),
        " ",
        name
      ] }, void 0, true, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/OrderItem.jsx",
        lineNumber: 14,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { "data-auto-id": "item-total-price", className: "font-bold", children: formatCurrency(totalPrice) }, void 0, false, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/OrderItem.jsx",
        lineNumber: 17,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/OrderItem.jsx",
      lineNumber: 13,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { "data-auto-id": "order-ingredients", className: "text-sm capitalize italic text-stone-500", children: isLoadingIngredients ? "Loading..." : ingredients.join(", ") }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/OrderItem.jsx",
      lineNumber: 19,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/OrderItem.jsx",
    lineNumber: 12,
    columnNumber: 10
  }, this);
}
_c = OrderItem;
export default OrderItem;
var _c;
$RefreshReg$(_c, "OrderItem");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/OrderItem.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU1U7QUFUViwyQkFBdUI7QUFBUTtBQUFxQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVwRCxTQUFTQSxVQUFVO0FBQUEsRUFBRUM7QUFBQUEsRUFBTUM7QUFBQUEsRUFBc0JDO0FBQVksR0FBRztBQUM5RCxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsSUFBVUM7QUFBQUEsSUFBTUM7QUFBQUEsRUFBVyxJQUFJTDtBQUV2QyxTQUNFLHVCQUFDLFFBQUcsV0FBVSxrQkFDWjtBQUFBLDJCQUFDLFNBQUksV0FBVSxtREFDYjtBQUFBLDZCQUFDLE9BQ0M7QUFBQSwrQkFBQyxVQUFLLGdCQUFhLGlCQUFnQixXQUFVLGFBQWFHO0FBQUFBO0FBQUFBLFVBQVM7QUFBQSxhQUFuRTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBFO0FBQUEsUUFBTztBQUFBLFFBQUVDO0FBQUFBLFdBRHJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BQ0EsdUJBQUMsT0FBRSxnQkFBYSxvQkFBbUIsV0FBVSxhQUFhRSx5QkFBZUQsVUFBVSxLQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQXFGO0FBQUEsU0FKdkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUtBO0FBQUEsSUFDQSx1QkFBQyxPQUFFLGdCQUFhLHFCQUFvQixXQUFVLDRDQUMzQ0osaUNBQXVCLGVBQWVDLFlBQVlLLEtBQUssSUFBSSxLQUQ5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxPQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FVQTtBQUVKO0FBQUNDLEtBaEJRVDtBQWtCVCxlQUFlQTtBQUFVLElBQUFTO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJPcmRlckl0ZW0iLCJpdGVtIiwiaXNMb2FkaW5nSW5ncmVkaWVudHMiLCJpbmdyZWRpZW50cyIsInF1YW50aXR5IiwibmFtZSIsInRvdGFsUHJpY2UiLCJmb3JtYXRDdXJyZW5jeSIsImpvaW4iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIk9yZGVySXRlbS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZm9ybWF0Q3VycmVuY3kgfSBmcm9tICcuLi8uLi91dGlscy9oZWxwZXJzJztcblxuZnVuY3Rpb24gT3JkZXJJdGVtKHsgaXRlbSwgaXNMb2FkaW5nSW5ncmVkaWVudHMsIGluZ3JlZGllbnRzIH0pIHtcbiAgY29uc3QgeyBxdWFudGl0eSwgbmFtZSwgdG90YWxQcmljZSB9ID0gaXRlbTtcblxuICByZXR1cm4gKFxuICAgIDxsaSBjbGFzc05hbWU9XCJzcGFjZS15LTEgcHktM1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW4gZ2FwLTQgdGV4dC1zbVwiPlxuICAgICAgICA8cD5cbiAgICAgICAgICA8c3BhbiBkYXRhLWF1dG8taWQ9XCJpdGVtLXF1YW50aXR5XCIgY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+e3F1YW50aXR5fSZ0aW1lczs8L3NwYW4+IHtuYW1lfVxuICAgICAgICA8L3A+XG4gICAgICAgIDxwIGRhdGEtYXV0by1pZD1cIml0ZW0tdG90YWwtcHJpY2VcIiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj57Zm9ybWF0Q3VycmVuY3kodG90YWxQcmljZSl9PC9wPlxuICAgICAgPC9kaXY+XG4gICAgICA8cCBkYXRhLWF1dG8taWQ9XCJvcmRlci1pbmdyZWRpZW50c1wiIGNsYXNzTmFtZT1cInRleHQtc20gY2FwaXRhbGl6ZSBpdGFsaWMgdGV4dC1zdG9uZS01MDBcIj5cbiAgICAgICAge2lzTG9hZGluZ0luZ3JlZGllbnRzID8gJ0xvYWRpbmcuLi4nIDogaW5ncmVkaWVudHMuam9pbignLCAnKX1cbiAgICAgIDwvcD5cbiAgICA8L2xpPlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBPcmRlckl0ZW07XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jdXN0b2NhbC9Eb2N1bWVudHMvRGV2ZWxvcG1lbnQvRmFzdC1QaXp6YS1SZWFjdC1JbnRlZ3JhdGlvbi1UZXN0cy9zcmMvZmVhdHVyZXMvb3JkZXIvT3JkZXJJdGVtLmpzeCJ9