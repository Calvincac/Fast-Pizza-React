import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/menu/MenuItem.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/MenuItem.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useDispatch, useSelector } from "/node_modules/.vite/deps/react-redux.js?v=9f68b94c";
import Button from "/src/ui/Button.jsx";
import DeleteItem from "/src/features/cart/DeleteItem.jsx";
import UpdateItemQuantity from "/src/features/cart/UpdateItemQuantity.jsx";
import { formatCurrency } from "/src/utils/helpers.js";
import { addItem, getCurrentQuantityById } from "/src/features/cart/cartSlice.js";
function MenuItem({
  pizza
}) {
  _s();
  const dispatch = useDispatch();
  const {
    id,
    name,
    unitPrice,
    ingredients,
    soldOut,
    imageUrl
  } = pizza;
  const currentQuantity = useSelector(getCurrentQuantityById(id));
  const isInCart = currentQuantity > 0;
  function handleAddToCart() {
    const newItem = {
      pizzaId: id,
      name,
      quantity: 1,
      unitPrice,
      totalPrice: unitPrice * 1
    };
    dispatch(addItem(newItem));
  }
  return /* @__PURE__ */ jsxDEV("li", { className: "flex gap-4 py-2", children: [
    /* @__PURE__ */ jsxDEV("img", { src: imageUrl, alt: name, className: `h-24 ${soldOut ? "opacity-70 grayscale" : ""}` }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/MenuItem.jsx",
      lineNumber: 34,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex grow flex-col pt-0.5", children: [
      /* @__PURE__ */ jsxDEV("p", { "data-auto-id": "pizza-name", className: "font-medium", children: name }, void 0, false, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/MenuItem.jsx",
        lineNumber: 36,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { "data-auto-id": "pizza-ingradients", className: "text-sm capitalize italic text-stone-500", children: ingredients.join(", ") }, void 0, false, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/MenuItem.jsx",
        lineNumber: 37,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-auto flex items-center justify-between", children: [
        !soldOut ? /* @__PURE__ */ jsxDEV("p", { "data-auto-id": "pizza-price", className: "text-sm", children: formatCurrency(unitPrice) }, void 0, false, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/MenuItem.jsx",
          lineNumber: 41,
          columnNumber: 23
        }, this) : /* @__PURE__ */ jsxDEV("p", { "data-auto-id": "sold-out-pizza-price", className: "text-sm font-medium uppercase text-stone-500", children: "Sold out" }, void 0, false, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/MenuItem.jsx",
          lineNumber: 41,
          columnNumber: 107
        }, this),
        isInCart && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 sm:gap-8", children: [
          /* @__PURE__ */ jsxDEV(UpdateItemQuantity, { pizzaId: id, currentQuantity }, void 0, false, {
            fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/MenuItem.jsx",
            lineNumber: 46,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV(DeleteItem, { "data-auto-id": "delete-item", pizzaId: id }, void 0, false, {
            fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/MenuItem.jsx",
            lineNumber: 47,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/MenuItem.jsx",
          lineNumber: 45,
          columnNumber: 24
        }, this),
        !soldOut && !isInCart && /* @__PURE__ */ jsxDEV(Button, { "data-auto-id": "add-to-cart", type: "small", onClick: handleAddToCart, children: "Add to cart" }, void 0, false, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/MenuItem.jsx",
          lineNumber: 50,
          columnNumber: 37
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/MenuItem.jsx",
        lineNumber: 40,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/MenuItem.jsx",
      lineNumber: 35,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/MenuItem.jsx",
    lineNumber: 33,
    columnNumber: 10
  }, this);
}
_s(MenuItem, "kXpODCCzwPF9JyhnWIgXJz9QNT4=", false, function() {
  return [useDispatch, useSelector];
});
_c = MenuItem;
export default MenuItem;
var _c;
$RefreshReg$(_c, "MenuItem");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/menu/MenuItem.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEJNOzs7Ozs7Ozs7Ozs7Ozs7O0FBNUJOLFNBQVNBLGFBQWFDLG1CQUFtQjtBQUN6QyxPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGdCQUFnQjtBQUN2QixPQUFPQyx3QkFBd0I7QUFDL0IsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQVNDLFNBQVNDLDhCQUE4QjtBQUVoRCxTQUFTQyxTQUFTO0FBQUEsRUFBRUM7QUFBTSxHQUFHO0FBQUFDLEtBQUE7QUFDM0IsUUFBTUMsV0FBV1gsWUFBWTtBQUU3QixRQUFNO0FBQUEsSUFBRVk7QUFBQUEsSUFBSUM7QUFBQUEsSUFBTUM7QUFBQUEsSUFBV0M7QUFBQUEsSUFBYUM7QUFBQUEsSUFBU0M7QUFBQUEsRUFBUyxJQUFJUjtBQUVoRSxRQUFNUyxrQkFBa0JqQixZQUFZTSx1QkFBdUJLLEVBQUUsQ0FBQztBQUM5RCxRQUFNTyxXQUFXRCxrQkFBa0I7QUFFbkMsV0FBU0Usa0JBQWtCO0FBQ3pCLFVBQU1DLFVBQVU7QUFBQSxNQUNkQyxTQUFTVjtBQUFBQSxNQUNUQztBQUFBQSxNQUNBVSxVQUFVO0FBQUEsTUFDVlQ7QUFBQUEsTUFDQVUsWUFBWVYsWUFBWTtBQUFBLElBQzFCO0FBQ0FILGFBQVNMLFFBQVFlLE9BQU8sQ0FBQztBQUFBLEVBQzNCO0FBRUEsU0FDRSx1QkFBQyxRQUFHLFdBQVUsbUJBQ1o7QUFBQSwyQkFBQyxTQUNDLEtBQUtKLFVBQ0wsS0FBS0osTUFDTCxXQUFZLFFBQU9HLFVBQVUseUJBQXlCLEVBQUcsTUFIM0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUc2RDtBQUFBLElBRTdELHVCQUFDLFNBQUksV0FBVSw2QkFDYjtBQUFBLDZCQUFDLE9BQUUsZ0JBQWEsY0FBYSxXQUFVLGVBQWVILGtCQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJEO0FBQUEsTUFDM0QsdUJBQUMsT0FBRSxnQkFBYSxxQkFBb0IsV0FBVSw0Q0FDM0NFLHNCQUFZVSxLQUFLLElBQUksS0FEeEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFDQSx1QkFBQyxTQUFJLFdBQVUsNkNBQ1o7QUFBQSxTQUFDVCxVQUNBLHVCQUFDLE9BQUUsZ0JBQWEsZUFBYyxXQUFVLFdBQVdYLHlCQUFlUyxTQUFTLEtBQTNFO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkUsSUFFN0UsdUJBQUMsT0FBRSxnQkFBYSx3QkFBdUIsV0FBVSxnREFBOEMsd0JBQS9GO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBR0RLLFlBQ0MsdUJBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsaUNBQUMsc0JBQ0MsU0FBU1AsSUFDVCxtQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVtQztBQUFBLFVBRW5DLHVCQUFDLGNBQVcsZ0JBQWEsZUFBYyxTQUFTQSxNQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUFtRDtBQUFBLGFBTHJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFNQTtBQUFBLFFBR0QsQ0FBQ0ksV0FBVyxDQUFDRyxZQUNaLHVCQUFDLFVBQU8sZ0JBQWEsZUFBYyxNQUFLLFNBQVEsU0FBU0MsaUJBQWdCLDJCQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQXRCSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsU0E3QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQThCQTtBQUFBLE9BcENGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FxQ0E7QUFFSjtBQUFDVixHQTNEUUYsVUFBUTtBQUFBLFVBQ0VSLGFBSU9DLFdBQVc7QUFBQTtBQUFBeUIsS0FMNUJsQjtBQTZEVCxlQUFlQTtBQUFTLElBQUFrQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlRGlzcGF0Y2giLCJ1c2VTZWxlY3RvciIsIkJ1dHRvbiIsIkRlbGV0ZUl0ZW0iLCJVcGRhdGVJdGVtUXVhbnRpdHkiLCJmb3JtYXRDdXJyZW5jeSIsImFkZEl0ZW0iLCJnZXRDdXJyZW50UXVhbnRpdHlCeUlkIiwiTWVudUl0ZW0iLCJwaXp6YSIsIl9zIiwiZGlzcGF0Y2giLCJpZCIsIm5hbWUiLCJ1bml0UHJpY2UiLCJpbmdyZWRpZW50cyIsInNvbGRPdXQiLCJpbWFnZVVybCIsImN1cnJlbnRRdWFudGl0eSIsImlzSW5DYXJ0IiwiaGFuZGxlQWRkVG9DYXJ0IiwibmV3SXRlbSIsInBpenphSWQiLCJxdWFudGl0eSIsInRvdGFsUHJpY2UiLCJqb2luIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJNZW51SXRlbS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRGlzcGF0Y2gsIHVzZVNlbGVjdG9yIH0gZnJvbSAncmVhY3QtcmVkdXgnO1xuaW1wb3J0IEJ1dHRvbiBmcm9tICcuLi8uLi91aS9CdXR0b24nO1xuaW1wb3J0IERlbGV0ZUl0ZW0gZnJvbSAnLi4vY2FydC9EZWxldGVJdGVtJztcbmltcG9ydCBVcGRhdGVJdGVtUXVhbnRpdHkgZnJvbSAnLi4vY2FydC9VcGRhdGVJdGVtUXVhbnRpdHknO1xuaW1wb3J0IHsgZm9ybWF0Q3VycmVuY3kgfSBmcm9tICcuLi8uLi91dGlscy9oZWxwZXJzJztcbmltcG9ydCB7IGFkZEl0ZW0sIGdldEN1cnJlbnRRdWFudGl0eUJ5SWQgfSBmcm9tICcuLi9jYXJ0L2NhcnRTbGljZSc7XG5cbmZ1bmN0aW9uIE1lbnVJdGVtKHsgcGl6emEgfSkge1xuICBjb25zdCBkaXNwYXRjaCA9IHVzZURpc3BhdGNoKCk7XG5cbiAgY29uc3QgeyBpZCwgbmFtZSwgdW5pdFByaWNlLCBpbmdyZWRpZW50cywgc29sZE91dCwgaW1hZ2VVcmwgfSA9IHBpenphO1xuXG4gIGNvbnN0IGN1cnJlbnRRdWFudGl0eSA9IHVzZVNlbGVjdG9yKGdldEN1cnJlbnRRdWFudGl0eUJ5SWQoaWQpKTtcbiAgY29uc3QgaXNJbkNhcnQgPSBjdXJyZW50UXVhbnRpdHkgPiAwO1xuXG4gIGZ1bmN0aW9uIGhhbmRsZUFkZFRvQ2FydCgpIHtcbiAgICBjb25zdCBuZXdJdGVtID0ge1xuICAgICAgcGl6emFJZDogaWQsXG4gICAgICBuYW1lLFxuICAgICAgcXVhbnRpdHk6IDEsXG4gICAgICB1bml0UHJpY2UsXG4gICAgICB0b3RhbFByaWNlOiB1bml0UHJpY2UgKiAxLFxuICAgIH07XG4gICAgZGlzcGF0Y2goYWRkSXRlbShuZXdJdGVtKSk7XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxsaSBjbGFzc05hbWU9XCJmbGV4IGdhcC00IHB5LTJcIj5cbiAgICAgIDxpbWdcbiAgICAgICAgc3JjPXtpbWFnZVVybH1cbiAgICAgICAgYWx0PXtuYW1lfVxuICAgICAgICBjbGFzc05hbWU9e2BoLTI0ICR7c29sZE91dCA/ICdvcGFjaXR5LTcwIGdyYXlzY2FsZScgOiAnJ31gfVxuICAgICAgLz5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBncm93IGZsZXgtY29sIHB0LTAuNVwiPlxuICAgICAgICA8cCBkYXRhLWF1dG8taWQ9XCJwaXp6YS1uYW1lXCIgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW1cIj57bmFtZX08L3A+XG4gICAgICAgIDxwIGRhdGEtYXV0by1pZD1cInBpenphLWluZ3JhZGllbnRzXCIgY2xhc3NOYW1lPVwidGV4dC1zbSBjYXBpdGFsaXplIGl0YWxpYyB0ZXh0LXN0b25lLTUwMFwiPlxuICAgICAgICAgIHtpbmdyZWRpZW50cy5qb2luKCcsICcpfVxuICAgICAgICA8L3A+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtYXV0byBmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWJldHdlZW5cIj5cbiAgICAgICAgICB7IXNvbGRPdXQgPyAoXG4gICAgICAgICAgICA8cCBkYXRhLWF1dG8taWQ9XCJwaXp6YS1wcmljZVwiIGNsYXNzTmFtZT1cInRleHQtc21cIj57Zm9ybWF0Q3VycmVuY3kodW5pdFByaWNlKX08L3A+XG4gICAgICAgICAgKSA6IChcbiAgICAgICAgICAgIDxwIGRhdGEtYXV0by1pZD1cInNvbGQtb3V0LXBpenphLXByaWNlXCIgY2xhc3NOYW1lPVwidGV4dC1zbSBmb250LW1lZGl1bSB1cHBlcmNhc2UgdGV4dC1zdG9uZS01MDBcIj5cbiAgICAgICAgICAgICAgU29sZCBvdXRcbiAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICApfVxuXG4gICAgICAgICAge2lzSW5DYXJ0ICYmIChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTMgc206Z2FwLThcIj5cbiAgICAgICAgICAgICAgPFVwZGF0ZUl0ZW1RdWFudGl0eVxuICAgICAgICAgICAgICAgIHBpenphSWQ9e2lkfVxuICAgICAgICAgICAgICAgIGN1cnJlbnRRdWFudGl0eT17Y3VycmVudFF1YW50aXR5fVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8RGVsZXRlSXRlbSBkYXRhLWF1dG8taWQ9XCJkZWxldGUtaXRlbVwiIHBpenphSWQ9e2lkfSAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgKX1cblxuICAgICAgICAgIHshc29sZE91dCAmJiAhaXNJbkNhcnQgJiYgKFxuICAgICAgICAgICAgPEJ1dHRvbiBkYXRhLWF1dG8taWQ9XCJhZGQtdG8tY2FydFwiIHR5cGU9XCJzbWFsbFwiIG9uQ2xpY2s9e2hhbmRsZUFkZFRvQ2FydH0+XG4gICAgICAgICAgICAgIEFkZCB0byBjYXJ0XG4gICAgICAgICAgICA8L0J1dHRvbj5cbiAgICAgICAgICApfVxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvbGk+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IE1lbnVJdGVtO1xuIl0sImZpbGUiOiIvVXNlcnMvY3VzdG9jYWwvRG9jdW1lbnRzL0RldmVsb3BtZW50L0Zhc3QtUGl6emEtUmVhY3QtSW50ZWdyYXRpb24tVGVzdHMvc3JjL2ZlYXR1cmVzL21lbnUvTWVudUl0ZW0uanN4In0=