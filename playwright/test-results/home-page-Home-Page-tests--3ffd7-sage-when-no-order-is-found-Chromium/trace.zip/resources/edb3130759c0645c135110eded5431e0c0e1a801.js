import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/App.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { RouterProvider, createBrowserRouter } from "/node_modules/.vite/deps/react-router-dom.js?v=9f68b94c";
import Home from "/src/ui/Home.jsx";
import Error from "/src/ui/Error.jsx?t=1726417015374";
import Menu, { loader as menuLoader } from "/src/features/menu/Menu.jsx";
import Cart from "/src/features/cart/Cart.jsx";
import CreateOrder, { action as createOrderAction } from "/src/features/order/CreateOrder.jsx";
import Order, { loader as orderLoader } from "/src/features/order/Order.jsx";
import { action as updateOrderAction } from "/src/features/order/UpdateOrder.jsx";
import AppLayout from "/src/ui/AppLayout.jsx";
const router = createBrowserRouter([{
  element: /* @__PURE__ */ jsxDEV(AppLayout, {}, void 0, false, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/App.jsx",
    lineNumber: 11,
    columnNumber: 12
  }, this),
  errorElement: /* @__PURE__ */ jsxDEV(Error, {}, void 0, false, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/App.jsx",
    lineNumber: 12,
    columnNumber: 17
  }, this),
  children: [{
    path: "/",
    element: /* @__PURE__ */ jsxDEV(Home, {}, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/App.jsx",
      lineNumber: 15,
      columnNumber: 14
    }, this)
  }, {
    path: "/menu",
    element: /* @__PURE__ */ jsxDEV(Menu, {}, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/App.jsx",
      lineNumber: 18,
      columnNumber: 14
    }, this),
    loader: menuLoader,
    errorElement: /* @__PURE__ */ jsxDEV(Error, {}, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/App.jsx",
      lineNumber: 20,
      columnNumber: 19
    }, this)
  }, {
    path: "/cart",
    element: /* @__PURE__ */ jsxDEV(Cart, {}, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/App.jsx",
      lineNumber: 23,
      columnNumber: 14
    }, this)
  }, {
    path: "/order/new",
    element: /* @__PURE__ */ jsxDEV(CreateOrder, {}, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/App.jsx",
      lineNumber: 26,
      columnNumber: 14
    }, this),
    action: createOrderAction
  }, {
    path: "/order/:orderId",
    element: /* @__PURE__ */ jsxDEV(Order, {}, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/App.jsx",
      lineNumber: 30,
      columnNumber: 14
    }, this),
    loader: orderLoader,
    errorElement: /* @__PURE__ */ jsxDEV(Error, {}, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/App.jsx",
      lineNumber: 32,
      columnNumber: 19
    }, this),
    action: updateOrderAction
  }]
}]);
function App() {
  return /* @__PURE__ */ jsxDEV(RouterProvider, { router }, void 0, false, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/App.jsx",
    lineNumber: 37,
    columnNumber: 10
  }, this);
}
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JhO0FBaEJiLDJCQUF5QkE7QUFBbUI7QUFBUTtBQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFdEUsT0FBT0MsVUFBVTtBQUNqQixPQUFPQyxXQUFXO0FBQ2xCLE9BQU9DLFFBQVFDLFVBQVVDLGtCQUFrQjtBQUMzQyxPQUFPQyxVQUFVO0FBQ2pCLE9BQU9DLGVBQ0xDLFVBQVVDLHlCQUNMO0FBQ1AsT0FBT0MsU0FBU04sVUFBVU8sbUJBQW1CO0FBQzdDLFNBQVNILFVBQVVJLHlCQUF5QjtBQUU1QyxPQUFPQyxlQUFlO0FBRXRCLE1BQU1DLFNBQVNkLG9CQUFvQixDQUNqQztBQUFBLEVBQ0VlLFNBQVMsdUJBQUMsZUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQVU7QUFBQSxFQUNuQkMsY0FBYyx1QkFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBTTtBQUFBLEVBRXBCQyxVQUFVLENBQ1I7QUFBQSxJQUNFQyxNQUFNO0FBQUEsSUFDTkgsU0FBUyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBSztBQUFBLEVBQ2hCLEdBQ0E7QUFBQSxJQUNFRyxNQUFNO0FBQUEsSUFDTkgsU0FBUyx1QkFBQyxVQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBSztBQUFBLElBQ2RYLFFBQVFDO0FBQUFBLElBQ1JXLGNBQWMsdUJBQUMsV0FBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU07QUFBQSxFQUN0QixHQUNBO0FBQUEsSUFBRUUsTUFBTTtBQUFBLElBQVNILFNBQVMsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUs7QUFBQSxFQUFJLEdBQ25DO0FBQUEsSUFDRUcsTUFBTTtBQUFBLElBQ05ILFNBQVMsdUJBQUMsaUJBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFZO0FBQUEsSUFDckJQLFFBQVFDO0FBQUFBLEVBQ1YsR0FDQTtBQUFBLElBQ0VTLE1BQU07QUFBQSxJQUNOSCxTQUFTLHVCQUFDLFdBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFNO0FBQUEsSUFDZlgsUUFBUU87QUFBQUEsSUFDUkssY0FBYyx1QkFBQyxXQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBTTtBQUFBLElBQ3BCUixRQUFRSTtBQUFBQSxFQUNWLENBQUM7QUFFTCxDQUFDLENBQ0Y7QUFFRCxTQUFTTyxNQUFNO0FBQ2IsU0FBTyx1QkFBQyxrQkFBZSxVQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBQStCO0FBQ3hDO0FBQUNDLEtBRlFEO0FBSVQsZUFBZUE7QUFBSSxJQUFBQztBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiY3JlYXRlQnJvd3NlclJvdXRlciIsIkhvbWUiLCJFcnJvciIsIk1lbnUiLCJsb2FkZXIiLCJtZW51TG9hZGVyIiwiQ2FydCIsIkNyZWF0ZU9yZGVyIiwiYWN0aW9uIiwiY3JlYXRlT3JkZXJBY3Rpb24iLCJPcmRlciIsIm9yZGVyTG9hZGVyIiwidXBkYXRlT3JkZXJBY3Rpb24iLCJBcHBMYXlvdXQiLCJyb3V0ZXIiLCJlbGVtZW50IiwiZXJyb3JFbGVtZW50IiwiY2hpbGRyZW4iLCJwYXRoIiwiQXBwIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJBcHAuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IFJvdXRlclByb3ZpZGVyLCBjcmVhdGVCcm93c2VyUm91dGVyIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5cbmltcG9ydCBIb21lIGZyb20gJy4vdWkvSG9tZSc7XG5pbXBvcnQgRXJyb3IgZnJvbSAnLi91aS9FcnJvcic7XG5pbXBvcnQgTWVudSwgeyBsb2FkZXIgYXMgbWVudUxvYWRlciB9IGZyb20gJy4vZmVhdHVyZXMvbWVudS9NZW51JztcbmltcG9ydCBDYXJ0IGZyb20gJy4vZmVhdHVyZXMvY2FydC9DYXJ0JztcbmltcG9ydCBDcmVhdGVPcmRlciwge1xuICBhY3Rpb24gYXMgY3JlYXRlT3JkZXJBY3Rpb24sXG59IGZyb20gJy4vZmVhdHVyZXMvb3JkZXIvQ3JlYXRlT3JkZXInO1xuaW1wb3J0IE9yZGVyLCB7IGxvYWRlciBhcyBvcmRlckxvYWRlciB9IGZyb20gJy4vZmVhdHVyZXMvb3JkZXIvT3JkZXInO1xuaW1wb3J0IHsgYWN0aW9uIGFzIHVwZGF0ZU9yZGVyQWN0aW9uIH0gZnJvbSAnLi9mZWF0dXJlcy9vcmRlci9VcGRhdGVPcmRlcic7XG5cbmltcG9ydCBBcHBMYXlvdXQgZnJvbSAnLi91aS9BcHBMYXlvdXQnO1xuXG5jb25zdCByb3V0ZXIgPSBjcmVhdGVCcm93c2VyUm91dGVyKFtcbiAge1xuICAgIGVsZW1lbnQ6IDxBcHBMYXlvdXQgLz4sXG4gICAgZXJyb3JFbGVtZW50OiA8RXJyb3IgLz4sXG5cbiAgICBjaGlsZHJlbjogW1xuICAgICAge1xuICAgICAgICBwYXRoOiAnLycsXG4gICAgICAgIGVsZW1lbnQ6IDxIb21lIC8+LFxuICAgICAgfSxcbiAgICAgIHtcbiAgICAgICAgcGF0aDogJy9tZW51JyxcbiAgICAgICAgZWxlbWVudDogPE1lbnUgLz4sXG4gICAgICAgIGxvYWRlcjogbWVudUxvYWRlcixcbiAgICAgICAgZXJyb3JFbGVtZW50OiA8RXJyb3IgLz4sXG4gICAgICB9LFxuICAgICAgeyBwYXRoOiAnL2NhcnQnLCBlbGVtZW50OiA8Q2FydCAvPiB9LFxuICAgICAge1xuICAgICAgICBwYXRoOiAnL29yZGVyL25ldycsXG4gICAgICAgIGVsZW1lbnQ6IDxDcmVhdGVPcmRlciAvPixcbiAgICAgICAgYWN0aW9uOiBjcmVhdGVPcmRlckFjdGlvbixcbiAgICAgIH0sXG4gICAgICB7XG4gICAgICAgIHBhdGg6ICcvb3JkZXIvOm9yZGVySWQnLFxuICAgICAgICBlbGVtZW50OiA8T3JkZXIgLz4sXG4gICAgICAgIGxvYWRlcjogb3JkZXJMb2FkZXIsXG4gICAgICAgIGVycm9yRWxlbWVudDogPEVycm9yIC8+LFxuICAgICAgICBhY3Rpb246IHVwZGF0ZU9yZGVyQWN0aW9uLFxuICAgICAgfSxcbiAgICBdLFxuICB9LFxuXSk7XG5cbmZ1bmN0aW9uIEFwcCgpIHtcbiAgcmV0dXJuIDxSb3V0ZXJQcm92aWRlciByb3V0ZXI9e3JvdXRlcn0gLz47XG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcDtcbiJdLCJmaWxlIjoiL1VzZXJzL2N1c3RvY2FsL0RvY3VtZW50cy9EZXZlbG9wbWVudC9GYXN0LVBpenphLVJlYWN0LUludGVncmF0aW9uLVRlc3RzL3NyYy9BcHAuanN4In0=