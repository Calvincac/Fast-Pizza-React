import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=9f68b94c"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=9f68b94c"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import App from "/src/App.jsx";
import "/src/index.css";
import { Provider } from "/node_modules/.vite/deps/react-redux.js?v=9f68b94c";
import store from "/src/store.js";
ReactDOM.createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxDEV(React.StrictMode, { children: /* @__PURE__ */ jsxDEV(Provider, { store, children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
  fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/main.jsx",
  lineNumber: 9,
  columnNumber: 7
}, this) }, void 0, false, {
  fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/main.jsx",
  lineNumber: 8,
  columnNumber: 5
}, this) }, void 0, false, {
  fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/main.jsx",
  lineNumber: 7,
  columnNumber: 61
}, this));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBVU07QUFWTixPQUFPQSxXQUFXO0FBQ2xCLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsU0FBUztBQUNoQixPQUFPO0FBQ1AsU0FBU0MsZ0JBQWdCO0FBQ3pCLE9BQU9DLFdBQVc7QUFFbEJILFNBQVNJLFdBQVdDLFNBQVNDLGVBQWUsTUFBTSxDQUFDLEVBQUVDLE9BQ25ELHVCQUFDLE1BQU0sWUFBTixFQUNDLGlDQUFDLFlBQVMsT0FDUixpQ0FBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBSSxLQUROO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FFQSxLQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FJQSxDQUNGIiwibmFtZXMiOlsiUmVhY3QiLCJSZWFjdERPTSIsIkFwcCIsIlByb3ZpZGVyIiwic3RvcmUiLCJjcmVhdGVSb290IiwiZG9jdW1lbnQiLCJnZXRFbGVtZW50QnlJZCIsInJlbmRlciJdLCJzb3VyY2VzIjpbIm1haW4uanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tICdyZWFjdCc7XG5pbXBvcnQgUmVhY3RET00gZnJvbSAncmVhY3QtZG9tL2NsaWVudCc7XG5pbXBvcnQgQXBwIGZyb20gJy4vQXBwJztcbmltcG9ydCAnLi9pbmRleC5jc3MnO1xuaW1wb3J0IHsgUHJvdmlkZXIgfSBmcm9tICdyZWFjdC1yZWR1eCc7XG5pbXBvcnQgc3RvcmUgZnJvbSAnLi9zdG9yZSc7XG5cblJlYWN0RE9NLmNyZWF0ZVJvb3QoZG9jdW1lbnQuZ2V0RWxlbWVudEJ5SWQoJ3Jvb3QnKSkucmVuZGVyKFxuICA8UmVhY3QuU3RyaWN0TW9kZT5cbiAgICA8UHJvdmlkZXIgc3RvcmU9e3N0b3JlfT5cbiAgICAgIDxBcHAgLz5cbiAgICA8L1Byb3ZpZGVyPlxuICA8L1JlYWN0LlN0cmljdE1vZGU+XG4pO1xuIl0sImZpbGUiOiIvVXNlcnMvY3VzdG9jYWwvRG9jdW1lbnRzL0RldmVsb3BtZW50L0Zhc3QtUGl6emEtUmVhY3QtSW50ZWdyYXRpb24tVGVzdHMvc3JjL21haW4uanN4In0=