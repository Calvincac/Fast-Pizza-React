import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cart/Cart.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/Cart.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import LinkButton from "/src/ui/LinkButton.jsx";
import Button from "/src/ui/Button.jsx";
import CartItem from "/src/features/cart/CartItem.jsx";
import EmptyCart from "/src/features/cart/EmptyCart.jsx";
import { useDispatch, useSelector } from "/node_modules/.vite/deps/react-redux.js?v=9f68b94c";
import { clearCart, getCart } from "/src/features/cart/cartSlice.js";
function Cart() {
  _s();
  const username = useSelector((state) => state.user.username);
  const cart = useSelector(getCart);
  const dispatch = useDispatch();
  if (!cart.length)
    return /* @__PURE__ */ jsxDEV(EmptyCart, {}, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/Cart.jsx",
      lineNumber: 13,
      columnNumber: 28
    }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-3", children: [
    /* @__PURE__ */ jsxDEV(LinkButton, { "data-auto-id": "back-button", to: "/menu", children: "← Back to menu" }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/Cart.jsx",
      lineNumber: 15,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h2", { "data-auto-id": "cart-message", className: "mt-7 text-xl font-semibold", children: [
      "Your cart, ",
      username
    ] }, void 0, true, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/Cart.jsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { className: "mt-3 divide-y divide-stone-200 border-b", children: cart.map((item) => /* @__PURE__ */ jsxDEV(CartItem, { item }, item.pizzaId, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/Cart.jsx",
      lineNumber: 20,
      columnNumber: 27
    }, this)) }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/Cart.jsx",
      lineNumber: 19,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "mt-6 space-x-2", children: [
      /* @__PURE__ */ jsxDEV(Button, { "data-auto-id": "order-pizza-button", to: "/order/new", type: "primary", children: "Order pizzas" }, void 0, false, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/Cart.jsx",
        lineNumber: 24,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV(Button, { "data-auto-id": "clear-cart-button", type: "secondary", onClick: () => dispatch(clearCart()), children: "Clear cart" }, void 0, false, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/Cart.jsx",
        lineNumber: 28,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/Cart.jsx",
      lineNumber: 23,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/Cart.jsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
}
_s(Cart, "vjPBhHDk8dFP6zg1m0CV/R/UmEU=", false, function() {
  return [useSelector, useSelector, useDispatch];
});
_c = Cart;
export default Cart;
var _c;
$RefreshReg$(_c, "Cart");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/Cart.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBWTJCOzs7Ozs7Ozs7Ozs7Ozs7O0FBWjNCLE9BQU9BLGdCQUFnQjtBQUN2QixPQUFPQyxZQUFZO0FBQ25CLE9BQU9DLGNBQWM7QUFDckIsT0FBT0MsZUFBZTtBQUN0QixTQUFTQyxhQUFhQyxtQkFBbUI7QUFDekMsU0FBU0MsV0FBV0MsZUFBZTtBQUVuQyxTQUFTQyxPQUFPO0FBQUFDLEtBQUE7QUFDZCxRQUFNQyxXQUFXTCxZQUFhTSxXQUFVQSxNQUFNQyxLQUFLRixRQUFRO0FBQzNELFFBQU1HLE9BQU9SLFlBQVlFLE9BQU87QUFDaEMsUUFBTU8sV0FBV1YsWUFBWTtBQUU3QixNQUFJLENBQUNTLEtBQUtFO0FBQVEsV0FBTyx1QkFBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVTtBQUVuQyxTQUNFLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsMkJBQUMsY0FBVyxnQkFBYSxlQUFjLElBQUcsU0FBUSw4QkFBbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFxRTtBQUFBLElBRXJFLHVCQUFDLFFBQUcsZ0JBQWEsZ0JBQWUsV0FBVSw4QkFBNkI7QUFBQTtBQUFBLE1BQVlMO0FBQUFBLFNBQW5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEY7QUFBQSxJQUU1Rix1QkFBQyxRQUFHLFdBQVUsMkNBQ1hHLGVBQUtHLElBQUtDLFVBQ1QsdUJBQUMsWUFBUyxRQUFpQkEsS0FBS0MsU0FBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF3QyxDQUN6QyxLQUhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FJQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLGtCQUNiO0FBQUEsNkJBQUMsVUFBTyxnQkFBYSxzQkFBcUIsSUFBRyxjQUFhLE1BQUssV0FBUyw0QkFBeEU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsTUFFQSx1QkFBQyxVQUFPLGdCQUFhLHFCQUFvQixNQUFLLGFBQVksU0FBUyxNQUFNSixTQUFTUixVQUFVLENBQUMsR0FBRSwwQkFBL0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FQRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUE7QUFBQSxPQW5CRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBb0JBO0FBRUo7QUFBQ0csR0E5QlFELE1BQUk7QUFBQSxVQUNNSCxhQUNKQSxhQUNJRCxXQUFXO0FBQUE7QUFBQWUsS0FIckJYO0FBZ0NULGVBQWVBO0FBQUssSUFBQVc7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkxpbmtCdXR0b24iLCJCdXR0b24iLCJDYXJ0SXRlbSIsIkVtcHR5Q2FydCIsInVzZURpc3BhdGNoIiwidXNlU2VsZWN0b3IiLCJjbGVhckNhcnQiLCJnZXRDYXJ0IiwiQ2FydCIsIl9zIiwidXNlcm5hbWUiLCJzdGF0ZSIsInVzZXIiLCJjYXJ0IiwiZGlzcGF0Y2giLCJsZW5ndGgiLCJtYXAiLCJpdGVtIiwicGl6emFJZCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ2FydC5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IExpbmtCdXR0b24gZnJvbSAnLi4vLi4vdWkvTGlua0J1dHRvbic7XG5pbXBvcnQgQnV0dG9uIGZyb20gJy4uLy4uL3VpL0J1dHRvbic7XG5pbXBvcnQgQ2FydEl0ZW0gZnJvbSAnLi9DYXJ0SXRlbSc7XG5pbXBvcnQgRW1wdHlDYXJ0IGZyb20gJy4vRW1wdHlDYXJ0JztcbmltcG9ydCB7IHVzZURpc3BhdGNoLCB1c2VTZWxlY3RvciB9IGZyb20gJ3JlYWN0LXJlZHV4JztcbmltcG9ydCB7IGNsZWFyQ2FydCwgZ2V0Q2FydCB9IGZyb20gJy4vY2FydFNsaWNlJztcblxuZnVuY3Rpb24gQ2FydCgpIHtcbiAgY29uc3QgdXNlcm5hbWUgPSB1c2VTZWxlY3Rvcigoc3RhdGUpID0+IHN0YXRlLnVzZXIudXNlcm5hbWUpO1xuICBjb25zdCBjYXJ0ID0gdXNlU2VsZWN0b3IoZ2V0Q2FydCk7XG4gIGNvbnN0IGRpc3BhdGNoID0gdXNlRGlzcGF0Y2goKTtcblxuICBpZiAoIWNhcnQubGVuZ3RoKSByZXR1cm4gPEVtcHR5Q2FydCAvPjtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicHgtNCBweS0zXCI+XG4gICAgICA8TGlua0J1dHRvbiBkYXRhLWF1dG8taWQ9XCJiYWNrLWJ1dHRvblwiIHRvPVwiL21lbnVcIj4mbGFycjsgQmFjayB0byBtZW51PC9MaW5rQnV0dG9uPlxuXG4gICAgICA8aDIgZGF0YS1hdXRvLWlkPVwiY2FydC1tZXNzYWdlXCIgY2xhc3NOYW1lPVwibXQtNyB0ZXh0LXhsIGZvbnQtc2VtaWJvbGRcIj5Zb3VyIGNhcnQsIHt1c2VybmFtZX08L2gyPlxuXG4gICAgICA8dWwgY2xhc3NOYW1lPVwibXQtMyBkaXZpZGUteSBkaXZpZGUtc3RvbmUtMjAwIGJvcmRlci1iXCI+XG4gICAgICAgIHtjYXJ0Lm1hcCgoaXRlbSkgPT4gKFxuICAgICAgICAgIDxDYXJ0SXRlbSBpdGVtPXtpdGVtfSBrZXk9e2l0ZW0ucGl6emFJZH0gLz5cbiAgICAgICAgKSl9XG4gICAgICA8L3VsPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTYgc3BhY2UteC0yXCI+XG4gICAgICAgIDxCdXR0b24gZGF0YS1hdXRvLWlkPVwib3JkZXItcGl6emEtYnV0dG9uXCIgdG89XCIvb3JkZXIvbmV3XCIgdHlwZT1cInByaW1hcnlcIj5cbiAgICAgICAgICBPcmRlciBwaXp6YXNcbiAgICAgICAgPC9CdXR0b24+XG5cbiAgICAgICAgPEJ1dHRvbiBkYXRhLWF1dG8taWQ9XCJjbGVhci1jYXJ0LWJ1dHRvblwiIHR5cGU9XCJzZWNvbmRhcnlcIiBvbkNsaWNrPXsoKSA9PiBkaXNwYXRjaChjbGVhckNhcnQoKSl9PlxuICAgICAgICAgIENsZWFyIGNhcnRcbiAgICAgICAgPC9CdXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQ2FydDtcbiJdLCJmaWxlIjoiL1VzZXJzL2N1c3RvY2FsL0RvY3VtZW50cy9EZXZlbG9wbWVudC9GYXN0LVBpenphLVJlYWN0LUludGVncmF0aW9uLVRlc3RzL3NyYy9mZWF0dXJlcy9jYXJ0L0NhcnQuanN4In0=