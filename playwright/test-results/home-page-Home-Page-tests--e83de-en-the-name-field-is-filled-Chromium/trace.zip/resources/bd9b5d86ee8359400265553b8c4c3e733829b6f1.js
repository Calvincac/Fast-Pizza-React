import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/order/CreateOrder.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f68b94c"; const useState = __vite__cjsImport3_react["useState"];
import { Form, redirect, useActionData, useNavigation } from "/node_modules/.vite/deps/react-router-dom.js?v=9f68b94c";
import { createOrder } from "/src/services/apiRestaurant.js";
import Button from "/src/ui/Button.jsx";
import EmptyCart from "/src/features/cart/EmptyCart.jsx";
import { useDispatch, useSelector } from "/node_modules/.vite/deps/react-redux.js?v=9f68b94c";
import { clearCart, getCart, getTotalCartPrice } from "/src/features/cart/cartSlice.js";
import store from "/src/store.js";
import { formatCurrency } from "/src/utils/helpers.js";
import { fetchAddress } from "/src/features/user/userSlice.js";
const isValidPhone = (str) => /^\+?\d{1,4}?[-.\s]?\(?\d{1,3}?\)?[-.\s]?\d{1,4}[-.\s]?\d{1,4}[-.\s]?\d{1,9}$/.test(str);
function CreateOrder() {
  _s();
  const [withPriority, setWithPriority] = useState(false);
  const {
    username,
    status: addressStatus,
    position,
    address,
    error: errorAddress
  } = useSelector((state) => state.user);
  const isLoadingAddress = addressStatus === "loading";
  const navigation = useNavigation();
  const isSubmitting = navigation.state === "submitting";
  const formErrors = useActionData();
  const dispatch = useDispatch();
  const cart = useSelector(getCart);
  const totalCartPrice = useSelector(getTotalCartPrice);
  const priorityPrice = withPriority ? totalCartPrice * 0.2 : 0;
  const totalPrice = totalCartPrice + priorityPrice;
  if (!cart.length)
    return /* @__PURE__ */ jsxDEV(EmptyCart, {}, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
      lineNumber: 34,
      columnNumber: 28
    }, this);
  return /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-6", children: [
    /* @__PURE__ */ jsxDEV("h2", { className: "mb-8 text-xl font-semibold", children: "Ready to order? Let's go!" }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
      lineNumber: 36,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(Form, { method: "POST", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "mb-5 flex flex-col gap-2 sm:flex-row sm:items-center", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "sm:basis-40", children: "First Name" }, void 0, false, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
          lineNumber: 41,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("input", { "data-auto-id": "customer-name", className: "input grow", type: "text", name: "customer", defaultValue: username, required: true }, void 0, false, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
          lineNumber: 42,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
        lineNumber: 40,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-5 flex flex-col gap-2 sm:flex-row sm:items-center", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "sm:basis-40", children: "Phone number" }, void 0, false, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
          lineNumber: 46,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grow", children: [
          /* @__PURE__ */ jsxDEV("input", { "data-auto-id": "customer-phone", className: "input w-full", type: "tel", name: "phone", required: true }, void 0, false, {
            fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
            lineNumber: 48,
            columnNumber: 13
          }, this),
          formErrors?.phone && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 rounded-md bg-red-100 p-2 text-xs text-red-700", children: formErrors.phone }, void 0, false, {
            fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
            lineNumber: 49,
            columnNumber: 35
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
          lineNumber: 47,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
        lineNumber: 45,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "relative mb-5 flex flex-col gap-2 sm:flex-row sm:items-center", children: [
        /* @__PURE__ */ jsxDEV("label", { className: "sm:basis-40", children: "Address" }, void 0, false, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
          lineNumber: 56,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grow", children: [
          /* @__PURE__ */ jsxDEV("input", { "data-auto-id": "customer-address", className: "input w-full", type: "text", name: "address", disabled: isLoadingAddress, defaultValue: address, required: true }, void 0, false, {
            fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
            lineNumber: 58,
            columnNumber: 13
          }, this),
          addressStatus === "error" && /* @__PURE__ */ jsxDEV("p", { className: "mt-2 rounded-md bg-red-100 p-2 text-xs text-red-700", children: errorAddress }, void 0, false, {
            fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
            lineNumber: 59,
            columnNumber: 43
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
          lineNumber: 57,
          columnNumber: 11
        }, this),
        !position.latitude && !position.longitude && /* @__PURE__ */ jsxDEV("span", { className: "absolute right-[3px] top-[3px] z-50 md:right-[5px] md:top-[5px]", children: /* @__PURE__ */ jsxDEV(Button, { "data-auto-id": "customer-location-finder", disabled: isLoadingAddress, type: "small", onClick: (e) => {
          e.preventDefault();
          dispatch(fetchAddress());
        }, children: "Get position" }, void 0, false, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
          lineNumber: 65,
          columnNumber: 15
        }, this) }, void 0, false, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
          lineNumber: 64,
          columnNumber: 57
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
        lineNumber: 55,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "mb-12 flex items-center gap-5", children: [
        /* @__PURE__ */ jsxDEV("input", { "data-auto-id": "priority-checkbox", className: "h-6 w-6 accent-yellow-400 focus:outline-none focus:ring focus:ring-yellow-400 focus:ring-offset-2", type: "checkbox", name: "priority", id: "priority", value: withPriority, onChange: (e) => setWithPriority(e.target.checked) }, void 0, false, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
          lineNumber: 75,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("label", { htmlFor: "priority", className: "font-medium", children: "Want to yo give your order priority?" }, void 0, false, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
          lineNumber: 76,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
        lineNumber: 74,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("input", { type: "hidden", name: "cart", value: JSON.stringify(cart) }, void 0, false, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
          lineNumber: 82,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("input", { type: "hidden", name: "position", value: position.longitude && position.latitude ? `${position.latitude},${position.longitude}` : "" }, void 0, false, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
          lineNumber: 83,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(Button, { "data-auto-id": "order-button", disabled: isSubmitting || isLoadingAddress, type: "primary", children: isSubmitting ? "Placing order...." : `Order now from ${formatCurrency(totalPrice)}` }, void 0, false, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
          lineNumber: 85,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
        lineNumber: 81,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
      lineNumber: 39,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx",
    lineNumber: 35,
    columnNumber: 10
  }, this);
}
_s(CreateOrder, "7iZ83TVthQdeRljqNI9LLroxTIA=", false, function() {
  return [useSelector, useNavigation, useActionData, useDispatch, useSelector, useSelector];
});
_c = CreateOrder;
export async function action({
  request
}) {
  const formData = await request.formData();
  const data = Object.fromEntries(formData);
  const order = {
    ...data,
    cart: JSON.parse(data.cart),
    priority: data.priority === "true"
  };
  console.log(order);
  const errors = {};
  if (!isValidPhone(order.phone))
    errors.phone = "Please give us your correct phone number. We might need it to contact you.";
  if (Object.keys(errors).length > 0)
    return errors;
  const newOrder = await createOrder(order);
  store.dispatch(clearCart());
  return redirect(`/order/${newOrder.id}`);
}
export default CreateOrder;
var _c;
$RefreshReg$(_c, "CreateOrder");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/CreateOrder.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBdUMyQjs7Ozs7Ozs7Ozs7Ozs7OztBQXZDM0IsU0FBU0EsZ0JBQWdCO0FBQ3pCLFNBQVNDLE1BQU1DLFVBQVVDLGVBQWVDLHFCQUFxQjtBQUM3RCxTQUFTQyxtQkFBbUI7QUFDNUIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxlQUFlO0FBQ3RCLFNBQVNDLGFBQWFDLG1CQUFtQjtBQUN6QyxTQUFTQyxXQUFXQyxTQUFTQyx5QkFBeUI7QUFDdEQsT0FBT0MsV0FBVztBQUNsQixTQUFTQyxzQkFBc0I7QUFDL0IsU0FBU0Msb0JBQW9CO0FBRzdCLE1BQU1DLGVBQWdCQyxTQUNwQiwrRUFBK0VDLEtBQzdFRCxHQUNGO0FBRUYsU0FBU0UsY0FBYztBQUFBQyxLQUFBO0FBQ3JCLFFBQU0sQ0FBQ0MsY0FBY0MsZUFBZSxJQUFJdEIsU0FBUyxLQUFLO0FBQ3RELFFBQU07QUFBQSxJQUNKdUI7QUFBQUEsSUFDQUMsUUFBUUM7QUFBQUEsSUFDUkM7QUFBQUEsSUFDQUM7QUFBQUEsSUFDQUMsT0FBT0M7QUFBQUEsRUFDVCxJQUFJcEIsWUFBYXFCLFdBQVVBLE1BQU1DLElBQUk7QUFDckMsUUFBTUMsbUJBQW1CUCxrQkFBa0I7QUFFM0MsUUFBTVEsYUFBYTdCLGNBQWM7QUFDakMsUUFBTThCLGVBQWVELFdBQVdILFVBQVU7QUFFMUMsUUFBTUssYUFBYWhDLGNBQWM7QUFDakMsUUFBTWlDLFdBQVc1QixZQUFZO0FBRTdCLFFBQU02QixPQUFPNUIsWUFBWUUsT0FBTztBQUNoQyxRQUFNMkIsaUJBQWlCN0IsWUFBWUcsaUJBQWlCO0FBQ3BELFFBQU0yQixnQkFBZ0JsQixlQUFlaUIsaUJBQWlCLE1BQU07QUFDNUQsUUFBTUUsYUFBYUYsaUJBQWlCQztBQUVwQyxNQUFJLENBQUNGLEtBQUtJO0FBQVEsV0FBTyx1QkFBQyxlQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBVTtBQUVuQyxTQUNFLHVCQUFDLFNBQUksV0FBVSxhQUNiO0FBQUEsMkJBQUMsUUFBRyxXQUFVLDhCQUE2Qix5Q0FBM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFvRTtBQUFBLElBR3BFLHVCQUFDLFFBQUssUUFBTyxRQUNYO0FBQUEsNkJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGVBQWMsMEJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUM7QUFBQSxRQUN6Qyx1QkFBQyxXQUNDLGdCQUFhLGlCQUNiLFdBQVUsY0FDVixNQUFLLFFBQ0wsTUFBSyxZQUNMLGNBQWNsQixVQUNkLFVBQVEsUUFOVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBTVU7QUFBQSxXQVJaO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLHdEQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGVBQWMsNEJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkM7QUFBQSxRQUMzQyx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLFdBQU0sZ0JBQWEsa0JBQWlCLFdBQVUsZ0JBQWUsTUFBSyxPQUFNLE1BQUssU0FBUSxVQUFRLFFBQTlGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQThGO0FBQUEsVUFDN0ZZLFlBQVlPLFNBQ1gsdUJBQUMsT0FBRSxXQUFVLHVEQUNWUCxxQkFBV08sU0FEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BRUEsdUJBQUMsU0FBSSxXQUFVLGlFQUNiO0FBQUEsK0JBQUMsV0FBTSxXQUFVLGVBQWMsdUJBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBc0M7QUFBQSxRQUN0Qyx1QkFBQyxTQUFJLFdBQVUsUUFDYjtBQUFBLGlDQUFDLFdBQ0MsZ0JBQWEsb0JBQ2IsV0FBVSxnQkFDVixNQUFLLFFBQ0wsTUFBSyxXQUNMLFVBQVVWLGtCQUNWLGNBQWNMLFNBQ2QsVUFBUSxRQVBWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBT1U7QUFBQSxVQUVURixrQkFBa0IsV0FDakIsdUJBQUMsT0FBRSxXQUFVLHVEQUNWSSwwQkFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUVBO0FBQUEsYUFiSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBZUE7QUFBQSxRQUVDLENBQUNILFNBQVNpQixZQUFZLENBQUNqQixTQUFTa0IsYUFDL0IsdUJBQUMsVUFBSyxXQUFVLG1FQUNkLGlDQUFDLFVBQ0MsZ0JBQWEsNEJBQ2IsVUFBVVosa0JBQ1YsTUFBSyxTQUNMLFNBQVVhLE9BQU07QUFDZEEsWUFBRUMsZUFBZTtBQUNqQlYsbUJBQVNyQixhQUFhLENBQUM7QUFBQSxRQUN6QixHQUFFLDRCQVBKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFVQSxLQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFdBaENKO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFrQ0E7QUFBQSxNQUVBLHVCQUFDLFNBQUksV0FBVSxpQ0FDYjtBQUFBLCtCQUFDLFdBQ0MsZ0JBQWEscUJBQ2IsV0FBVSxxR0FDVixNQUFLLFlBQ0wsTUFBSyxZQUNMLElBQUcsWUFDSCxPQUFPTSxjQUNQLFVBQVd3QixPQUFNdkIsZ0JBQWdCdUIsRUFBRUUsT0FBT0MsT0FBTyxLQVBuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT3FEO0FBQUEsUUFFckQsdUJBQUMsV0FBTSxTQUFRLFlBQVcsV0FBVSxlQUFhLG9EQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxXQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFhQTtBQUFBLE1BRUEsdUJBQUMsU0FDQztBQUFBLCtCQUFDLFdBQU0sTUFBSyxVQUFTLE1BQUssUUFBTyxPQUFPQyxLQUFLQyxVQUFVYixJQUFJLEtBQTNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNkQ7QUFBQSxRQUM3RCx1QkFBQyxXQUNDLE1BQUssVUFDTCxNQUFLLFlBQ0wsT0FDRVgsU0FBU2tCLGFBQWFsQixTQUFTaUIsV0FDMUIsR0FBRWpCLFNBQVNpQixRQUFTLElBQUdqQixTQUFTa0IsU0FBVSxLQUMzQyxNQU5SO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPRztBQUFBLFFBR0gsdUJBQUMsVUFBTyxnQkFBYSxnQkFBZSxVQUFVVixnQkFBZ0JGLGtCQUFrQixNQUFLLFdBQ2xGRSx5QkFDRyxzQkFDQyxrQkFBaUJwQixlQUFlMEIsVUFBVSxDQUFFLE1BSG5EO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJQTtBQUFBLFdBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFpQkE7QUFBQSxTQTdGRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBOEZBO0FBQUEsT0FsR0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQW1HQTtBQUVKO0FBQUNwQixHQTlIUUQsYUFBVztBQUFBLFVBUWRWLGFBR2VMLGVBR0FELGVBQ0ZLLGFBRUpDLGFBQ1VBLFdBQVc7QUFBQTtBQUFBMEMsS0FsQjNCaEM7QUFnSVQsc0JBQXNCaUMsT0FBTztBQUFBLEVBQUVDO0FBQVEsR0FBRztBQUN4QyxRQUFNQyxXQUFXLE1BQU1ELFFBQVFDLFNBQVM7QUFDeEMsUUFBTUMsT0FBT0MsT0FBT0MsWUFBWUgsUUFBUTtBQUV4QyxRQUFNSSxRQUFRO0FBQUEsSUFDWixHQUFHSDtBQUFBQSxJQUNIbEIsTUFBTVksS0FBS1UsTUFBTUosS0FBS2xCLElBQUk7QUFBQSxJQUMxQnVCLFVBQVVMLEtBQUtLLGFBQWE7QUFBQSxFQUM5QjtBQUVBQyxVQUFRQyxJQUFJSixLQUFLO0FBRWpCLFFBQU1LLFNBQVMsQ0FBQztBQUNoQixNQUFJLENBQUMvQyxhQUFhMEMsTUFBTWhCLEtBQUs7QUFDM0JxQixXQUFPckIsUUFDTDtBQUVKLE1BQUljLE9BQU9RLEtBQUtELE1BQU0sRUFBRXRCLFNBQVM7QUFBRyxXQUFPc0I7QUFHM0MsUUFBTUUsV0FBVyxNQUFNNUQsWUFBWXFELEtBQUs7QUFHeEM3QyxRQUFNdUIsU0FBUzFCLFVBQVUsQ0FBQztBQUUxQixTQUFPUixTQUFVLFVBQVMrRCxTQUFTQyxFQUFHLEVBQUM7QUFDekM7QUFFQSxlQUFlL0M7QUFBWSxJQUFBZ0M7QUFBQWdCLGFBQUFoQixJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJGb3JtIiwicmVkaXJlY3QiLCJ1c2VBY3Rpb25EYXRhIiwidXNlTmF2aWdhdGlvbiIsImNyZWF0ZU9yZGVyIiwiQnV0dG9uIiwiRW1wdHlDYXJ0IiwidXNlRGlzcGF0Y2giLCJ1c2VTZWxlY3RvciIsImNsZWFyQ2FydCIsImdldENhcnQiLCJnZXRUb3RhbENhcnRQcmljZSIsInN0b3JlIiwiZm9ybWF0Q3VycmVuY3kiLCJmZXRjaEFkZHJlc3MiLCJpc1ZhbGlkUGhvbmUiLCJzdHIiLCJ0ZXN0IiwiQ3JlYXRlT3JkZXIiLCJfcyIsIndpdGhQcmlvcml0eSIsInNldFdpdGhQcmlvcml0eSIsInVzZXJuYW1lIiwic3RhdHVzIiwiYWRkcmVzc1N0YXR1cyIsInBvc2l0aW9uIiwiYWRkcmVzcyIsImVycm9yIiwiZXJyb3JBZGRyZXNzIiwic3RhdGUiLCJ1c2VyIiwiaXNMb2FkaW5nQWRkcmVzcyIsIm5hdmlnYXRpb24iLCJpc1N1Ym1pdHRpbmciLCJmb3JtRXJyb3JzIiwiZGlzcGF0Y2giLCJjYXJ0IiwidG90YWxDYXJ0UHJpY2UiLCJwcmlvcml0eVByaWNlIiwidG90YWxQcmljZSIsImxlbmd0aCIsInBob25lIiwibGF0aXR1ZGUiLCJsb25naXR1ZGUiLCJlIiwicHJldmVudERlZmF1bHQiLCJ0YXJnZXQiLCJjaGVja2VkIiwiSlNPTiIsInN0cmluZ2lmeSIsIl9jIiwiYWN0aW9uIiwicmVxdWVzdCIsImZvcm1EYXRhIiwiZGF0YSIsIk9iamVjdCIsImZyb21FbnRyaWVzIiwib3JkZXIiLCJwYXJzZSIsInByaW9yaXR5IiwiY29uc29sZSIsImxvZyIsImVycm9ycyIsImtleXMiLCJuZXdPcmRlciIsImlkIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQ3JlYXRlT3JkZXIuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgRm9ybSwgcmVkaXJlY3QsIHVzZUFjdGlvbkRhdGEsIHVzZU5hdmlnYXRpb24gfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcbmltcG9ydCB7IGNyZWF0ZU9yZGVyIH0gZnJvbSAnLi4vLi4vc2VydmljZXMvYXBpUmVzdGF1cmFudCc7XG5pbXBvcnQgQnV0dG9uIGZyb20gJy4uLy4uL3VpL0J1dHRvbic7XG5pbXBvcnQgRW1wdHlDYXJ0IGZyb20gJy4uL2NhcnQvRW1wdHlDYXJ0JztcbmltcG9ydCB7IHVzZURpc3BhdGNoLCB1c2VTZWxlY3RvciB9IGZyb20gJ3JlYWN0LXJlZHV4JztcbmltcG9ydCB7IGNsZWFyQ2FydCwgZ2V0Q2FydCwgZ2V0VG90YWxDYXJ0UHJpY2UgfSBmcm9tICcuLi9jYXJ0L2NhcnRTbGljZSc7XG5pbXBvcnQgc3RvcmUgZnJvbSAnLi4vLi4vc3RvcmUnO1xuaW1wb3J0IHsgZm9ybWF0Q3VycmVuY3kgfSBmcm9tICcuLi8uLi91dGlscy9oZWxwZXJzJztcbmltcG9ydCB7IGZldGNoQWRkcmVzcyB9IGZyb20gJy4uL3VzZXIvdXNlclNsaWNlJztcblxuLy8gaHR0cHM6Ly91aWJha2VyeS5pby9yZWdleC1saWJyYXJ5L3Bob25lLW51bWJlclxuY29uc3QgaXNWYWxpZFBob25lID0gKHN0cikgPT5cbiAgL15cXCs/XFxkezEsNH0/Wy0uXFxzXT9cXCg/XFxkezEsM30/XFwpP1stLlxcc10/XFxkezEsNH1bLS5cXHNdP1xcZHsxLDR9Wy0uXFxzXT9cXGR7MSw5fSQvLnRlc3QoXG4gICAgc3RyXG4gICk7XG5cbmZ1bmN0aW9uIENyZWF0ZU9yZGVyKCkge1xuICBjb25zdCBbd2l0aFByaW9yaXR5LCBzZXRXaXRoUHJpb3JpdHldID0gdXNlU3RhdGUoZmFsc2UpO1xuICBjb25zdCB7XG4gICAgdXNlcm5hbWUsXG4gICAgc3RhdHVzOiBhZGRyZXNzU3RhdHVzLFxuICAgIHBvc2l0aW9uLFxuICAgIGFkZHJlc3MsXG4gICAgZXJyb3I6IGVycm9yQWRkcmVzcyxcbiAgfSA9IHVzZVNlbGVjdG9yKChzdGF0ZSkgPT4gc3RhdGUudXNlcik7XG4gIGNvbnN0IGlzTG9hZGluZ0FkZHJlc3MgPSBhZGRyZXNzU3RhdHVzID09PSAnbG9hZGluZyc7XG5cbiAgY29uc3QgbmF2aWdhdGlvbiA9IHVzZU5hdmlnYXRpb24oKTtcbiAgY29uc3QgaXNTdWJtaXR0aW5nID0gbmF2aWdhdGlvbi5zdGF0ZSA9PT0gJ3N1Ym1pdHRpbmcnO1xuXG4gIGNvbnN0IGZvcm1FcnJvcnMgPSB1c2VBY3Rpb25EYXRhKCk7XG4gIGNvbnN0IGRpc3BhdGNoID0gdXNlRGlzcGF0Y2goKTtcblxuICBjb25zdCBjYXJ0ID0gdXNlU2VsZWN0b3IoZ2V0Q2FydCk7XG4gIGNvbnN0IHRvdGFsQ2FydFByaWNlID0gdXNlU2VsZWN0b3IoZ2V0VG90YWxDYXJ0UHJpY2UpO1xuICBjb25zdCBwcmlvcml0eVByaWNlID0gd2l0aFByaW9yaXR5ID8gdG90YWxDYXJ0UHJpY2UgKiAwLjIgOiAwO1xuICBjb25zdCB0b3RhbFByaWNlID0gdG90YWxDYXJ0UHJpY2UgKyBwcmlvcml0eVByaWNlO1xuXG4gIGlmICghY2FydC5sZW5ndGgpIHJldHVybiA8RW1wdHlDYXJ0IC8+O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJweC00IHB5LTZcIj5cbiAgICAgIDxoMiBjbGFzc05hbWU9XCJtYi04IHRleHQteGwgZm9udC1zZW1pYm9sZFwiPlJlYWR5IHRvIG9yZGVyPyBMZXQncyBnbyE8L2gyPlxuXG4gICAgICB7LyogPEZvcm0gbWV0aG9kPVwiUE9TVFwiIGFjdGlvbj1cIi9vcmRlci9uZXdcIj4gKi99XG4gICAgICA8Rm9ybSBtZXRob2Q9XCJQT1NUXCI+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWItNSBmbGV4IGZsZXgtY29sIGdhcC0yIHNtOmZsZXgtcm93IHNtOml0ZW1zLWNlbnRlclwiPlxuICAgICAgICAgIDxsYWJlbCBjbGFzc05hbWU9XCJzbTpiYXNpcy00MFwiPkZpcnN0IE5hbWU8L2xhYmVsPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgZGF0YS1hdXRvLWlkPVwiY3VzdG9tZXItbmFtZVwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJpbnB1dCBncm93XCJcbiAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgIG5hbWU9XCJjdXN0b21lclwiXG4gICAgICAgICAgICBkZWZhdWx0VmFsdWU9e3VzZXJuYW1lfVxuICAgICAgICAgICAgcmVxdWlyZWRcbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTUgZmxleCBmbGV4LWNvbCBnYXAtMiBzbTpmbGV4LXJvdyBzbTppdGVtcy1jZW50ZXJcIj5cbiAgICAgICAgICA8bGFiZWwgY2xhc3NOYW1lPVwic206YmFzaXMtNDBcIj5QaG9uZSBudW1iZXI8L2xhYmVsPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3Jvd1wiPlxuICAgICAgICAgICAgPGlucHV0IGRhdGEtYXV0by1pZD1cImN1c3RvbWVyLXBob25lXCIgY2xhc3NOYW1lPVwiaW5wdXQgdy1mdWxsXCIgdHlwZT1cInRlbFwiIG5hbWU9XCJwaG9uZVwiIHJlcXVpcmVkIC8+XG4gICAgICAgICAgICB7Zm9ybUVycm9ycz8ucGhvbmUgJiYgKFxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJtdC0yIHJvdW5kZWQtbWQgYmctcmVkLTEwMCBwLTIgdGV4dC14cyB0ZXh0LXJlZC03MDBcIj5cbiAgICAgICAgICAgICAgICB7Zm9ybUVycm9ycy5waG9uZX1cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZSBtYi01IGZsZXggZmxleC1jb2wgZ2FwLTIgc206ZmxleC1yb3cgc206aXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgPGxhYmVsIGNsYXNzTmFtZT1cInNtOmJhc2lzLTQwXCI+QWRkcmVzczwvbGFiZWw+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncm93XCI+XG4gICAgICAgICAgICA8aW5wdXRcbiAgICAgICAgICAgICAgZGF0YS1hdXRvLWlkPVwiY3VzdG9tZXItYWRkcmVzc1wiXG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cImlucHV0IHctZnVsbFwiXG4gICAgICAgICAgICAgIHR5cGU9XCJ0ZXh0XCJcbiAgICAgICAgICAgICAgbmFtZT1cImFkZHJlc3NcIlxuICAgICAgICAgICAgICBkaXNhYmxlZD17aXNMb2FkaW5nQWRkcmVzc31cbiAgICAgICAgICAgICAgZGVmYXVsdFZhbHVlPXthZGRyZXNzfVxuICAgICAgICAgICAgICByZXF1aXJlZFxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIHthZGRyZXNzU3RhdHVzID09PSAnZXJyb3InICYmIChcbiAgICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibXQtMiByb3VuZGVkLW1kIGJnLXJlZC0xMDAgcC0yIHRleHQteHMgdGV4dC1yZWQtNzAwXCI+XG4gICAgICAgICAgICAgICAge2Vycm9yQWRkcmVzc31cbiAgICAgICAgICAgICAgPC9wPlxuICAgICAgICAgICAgKX1cbiAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgIHshcG9zaXRpb24ubGF0aXR1ZGUgJiYgIXBvc2l0aW9uLmxvbmdpdHVkZSAmJiAoXG4gICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJhYnNvbHV0ZSByaWdodC1bM3B4XSB0b3AtWzNweF0gei01MCBtZDpyaWdodC1bNXB4XSBtZDp0b3AtWzVweF1cIj5cbiAgICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICAgIGRhdGEtYXV0by1pZD1cImN1c3RvbWVyLWxvY2F0aW9uLWZpbmRlclwiXG4gICAgICAgICAgICAgICAgZGlzYWJsZWQ9e2lzTG9hZGluZ0FkZHJlc3N9XG4gICAgICAgICAgICAgICAgdHlwZT1cInNtYWxsXCJcbiAgICAgICAgICAgICAgICBvbkNsaWNrPXsoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgZS5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgICAgICAgZGlzcGF0Y2goZmV0Y2hBZGRyZXNzKCkpO1xuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBHZXQgcG9zaXRpb25cbiAgICAgICAgICAgICAgPC9CdXR0b24+XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgKX1cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYi0xMiBmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNVwiPlxuICAgICAgICAgIDxpbnB1dFxuICAgICAgICAgICAgZGF0YS1hdXRvLWlkPVwicHJpb3JpdHktY2hlY2tib3hcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC02IHctNiBhY2NlbnQteWVsbG93LTQwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZyBmb2N1czpyaW5nLXllbGxvdy00MDAgZm9jdXM6cmluZy1vZmZzZXQtMlwiXG4gICAgICAgICAgICB0eXBlPVwiY2hlY2tib3hcIlxuICAgICAgICAgICAgbmFtZT1cInByaW9yaXR5XCJcbiAgICAgICAgICAgIGlkPVwicHJpb3JpdHlcIlxuICAgICAgICAgICAgdmFsdWU9e3dpdGhQcmlvcml0eX1cbiAgICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gc2V0V2l0aFByaW9yaXR5KGUudGFyZ2V0LmNoZWNrZWQpfVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPGxhYmVsIGh0bWxGb3I9XCJwcmlvcml0eVwiIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAgICBXYW50IHRvIHlvIGdpdmUgeW91ciBvcmRlciBwcmlvcml0eT9cbiAgICAgICAgICA8L2xhYmVsPlxuICAgICAgICA8L2Rpdj5cblxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxpbnB1dCB0eXBlPVwiaGlkZGVuXCIgbmFtZT1cImNhcnRcIiB2YWx1ZT17SlNPTi5zdHJpbmdpZnkoY2FydCl9IC8+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICB0eXBlPVwiaGlkZGVuXCJcbiAgICAgICAgICAgIG5hbWU9XCJwb3NpdGlvblwiXG4gICAgICAgICAgICB2YWx1ZT17XG4gICAgICAgICAgICAgIHBvc2l0aW9uLmxvbmdpdHVkZSAmJiBwb3NpdGlvbi5sYXRpdHVkZVxuICAgICAgICAgICAgICAgID8gYCR7cG9zaXRpb24ubGF0aXR1ZGV9LCR7cG9zaXRpb24ubG9uZ2l0dWRlfWBcbiAgICAgICAgICAgICAgICA6ICcnXG4gICAgICAgICAgICB9XG4gICAgICAgICAgLz5cblxuICAgICAgICAgIDxCdXR0b24gZGF0YS1hdXRvLWlkPVwib3JkZXItYnV0dG9uXCIgZGlzYWJsZWQ9e2lzU3VibWl0dGluZyB8fCBpc0xvYWRpbmdBZGRyZXNzfSB0eXBlPVwicHJpbWFyeVwiPlxuICAgICAgICAgICAge2lzU3VibWl0dGluZ1xuICAgICAgICAgICAgICA/ICdQbGFjaW5nIG9yZGVyLi4uLidcbiAgICAgICAgICAgICAgOiBgT3JkZXIgbm93IGZyb20gJHtmb3JtYXRDdXJyZW5jeSh0b3RhbFByaWNlKX1gfVxuICAgICAgICAgIDwvQnV0dG9uPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvRm9ybT5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFjdGlvbih7IHJlcXVlc3QgfSkge1xuICBjb25zdCBmb3JtRGF0YSA9IGF3YWl0IHJlcXVlc3QuZm9ybURhdGEoKTtcbiAgY29uc3QgZGF0YSA9IE9iamVjdC5mcm9tRW50cmllcyhmb3JtRGF0YSk7XG5cbiAgY29uc3Qgb3JkZXIgPSB7XG4gICAgLi4uZGF0YSxcbiAgICBjYXJ0OiBKU09OLnBhcnNlKGRhdGEuY2FydCksXG4gICAgcHJpb3JpdHk6IGRhdGEucHJpb3JpdHkgPT09ICd0cnVlJyxcbiAgfTtcblxuICBjb25zb2xlLmxvZyhvcmRlcik7XG5cbiAgY29uc3QgZXJyb3JzID0ge307XG4gIGlmICghaXNWYWxpZFBob25lKG9yZGVyLnBob25lKSlcbiAgICBlcnJvcnMucGhvbmUgPVxuICAgICAgJ1BsZWFzZSBnaXZlIHVzIHlvdXIgY29ycmVjdCBwaG9uZSBudW1iZXIuIFdlIG1pZ2h0IG5lZWQgaXQgdG8gY29udGFjdCB5b3UuJztcblxuICBpZiAoT2JqZWN0LmtleXMoZXJyb3JzKS5sZW5ndGggPiAwKSByZXR1cm4gZXJyb3JzO1xuXG4gIC8vIElmIGV2ZXJ5dGhpbmcgaXMgb2theSwgY3JlYXRlIG5ldyBvcmRlciBhbmQgcmVkaXJlY3RcbiAgY29uc3QgbmV3T3JkZXIgPSBhd2FpdCBjcmVhdGVPcmRlcihvcmRlcik7XG5cbiAgLy8gRG8gTk9UIG92ZXJ1c2VcbiAgc3RvcmUuZGlzcGF0Y2goY2xlYXJDYXJ0KCkpO1xuXG4gIHJldHVybiByZWRpcmVjdChgL29yZGVyLyR7bmV3T3JkZXIuaWR9YCk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IENyZWF0ZU9yZGVyO1xuIl0sImZpbGUiOiIvVXNlcnMvY3VzdG9jYWwvRG9jdW1lbnRzL0RldmVsb3BtZW50L0Zhc3QtUGl6emEtUmVhY3QtSW50ZWdyYXRpb24tVGVzdHMvc3JjL2ZlYXR1cmVzL29yZGVyL0NyZWF0ZU9yZGVyLmpzeCJ9