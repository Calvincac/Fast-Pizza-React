import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/AppLayout.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/AppLayout.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import Header from "/src/ui/Header.jsx";
import Loader from "/src/ui/Loader.jsx";
import CartOverview from "/src/features/cart/CartOverview.jsx";
import { Outlet, useNavigation } from "/node_modules/.vite/deps/react-router-dom.js?v=9f68b94c";
function AppLayout() {
  _s();
  const navigation = useNavigation();
  const isLoading = navigation.state === "loading";
  return /* @__PURE__ */ jsxDEV("div", { className: "grid  h-screen grid-rows-[auto_1fr_auto]", children: [
    isLoading && /* @__PURE__ */ jsxDEV(Loader, {}, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/AppLayout.jsx",
      lineNumber: 11,
      columnNumber: 21
    }, this),
    /* @__PURE__ */ jsxDEV(Header, {}, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/AppLayout.jsx",
      lineNumber: 13,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "overflow-scroll", children: /* @__PURE__ */ jsxDEV("main", { className: "mx-auto max-w-3xl", children: /* @__PURE__ */ jsxDEV(Outlet, {}, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/AppLayout.jsx",
      lineNumber: 17,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/AppLayout.jsx",
      lineNumber: 16,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/AppLayout.jsx",
      lineNumber: 15,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(CartOverview, {}, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/AppLayout.jsx",
      lineNumber: 21,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/AppLayout.jsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
}
_s(AppLayout, "I2WaJhUM5KV32aS1+j3KKeVsgyA=", false, function() {
  return [useNavigation];
});
_c = AppLayout;
export default AppLayout;
var _c;
$RefreshReg$(_c, "AppLayout");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/AppLayout.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBV29COzs7Ozs7Ozs7Ozs7Ozs7O0FBWHBCLE9BQU9BLFlBQVk7QUFDbkIsT0FBT0MsWUFBWTtBQUNuQixPQUFPQyxrQkFBa0I7QUFDekIsU0FBU0MsUUFBUUMscUJBQXFCO0FBRXRDLFNBQVNDLFlBQVk7QUFBQUMsS0FBQTtBQUNuQixRQUFNQyxhQUFhSCxjQUFjO0FBQ2pDLFFBQU1JLFlBQVlELFdBQVdFLFVBQVU7QUFFdkMsU0FDRSx1QkFBQyxTQUFJLFdBQVUsNENBQ1pEO0FBQUFBLGlCQUFhLHVCQUFDLFlBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFPO0FBQUEsSUFFckIsdUJBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU87QUFBQSxJQUVQLHVCQUFDLFNBQUksV0FBVSxtQkFDYixpQ0FBQyxVQUFLLFdBQVUscUJBQ2QsaUNBQUMsWUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQU8sS0FEVDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUEsS0FIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBSUE7QUFBQSxJQUVBLHVCQUFDLGtCQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBYTtBQUFBLE9BWGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQVlBO0FBRUo7QUFBQ0YsR0FuQlFELFdBQVM7QUFBQSxVQUNHRCxhQUFhO0FBQUE7QUFBQU0sS0FEekJMO0FBcUJULGVBQWVBO0FBQVUsSUFBQUs7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIkhlYWRlciIsIkxvYWRlciIsIkNhcnRPdmVydmlldyIsIk91dGxldCIsInVzZU5hdmlnYXRpb24iLCJBcHBMYXlvdXQiLCJfcyIsIm5hdmlnYXRpb24iLCJpc0xvYWRpbmciLCJzdGF0ZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiQXBwTGF5b3V0LmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgSGVhZGVyIGZyb20gJy4vSGVhZGVyJztcbmltcG9ydCBMb2FkZXIgZnJvbSAnLi9Mb2FkZXInO1xuaW1wb3J0IENhcnRPdmVydmlldyBmcm9tICcuLi9mZWF0dXJlcy9jYXJ0L0NhcnRPdmVydmlldyc7XG5pbXBvcnQgeyBPdXRsZXQsIHVzZU5hdmlnYXRpb24gfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJztcblxuZnVuY3Rpb24gQXBwTGF5b3V0KCkge1xuICBjb25zdCBuYXZpZ2F0aW9uID0gdXNlTmF2aWdhdGlvbigpO1xuICBjb25zdCBpc0xvYWRpbmcgPSBuYXZpZ2F0aW9uLnN0YXRlID09PSAnbG9hZGluZyc7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgIGgtc2NyZWVuIGdyaWQtcm93cy1bYXV0b18xZnJfYXV0b11cIj5cbiAgICAgIHtpc0xvYWRpbmcgJiYgPExvYWRlciAvPn1cblxuICAgICAgPEhlYWRlciAvPlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LXNjcm9sbFwiPlxuICAgICAgICA8bWFpbiBjbGFzc05hbWU9XCJteC1hdXRvIG1heC13LTN4bFwiPlxuICAgICAgICAgIDxPdXRsZXQgLz5cbiAgICAgICAgPC9tYWluPlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxDYXJ0T3ZlcnZpZXcgLz5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwTGF5b3V0O1xuIl0sImZpbGUiOiIvVXNlcnMvY3VzdG9jYWwvRG9jdW1lbnRzL0RldmVsb3BtZW50L0Zhc3QtUGl6emEtUmVhY3QtSW50ZWdyYXRpb24tVGVzdHMvc3JjL3VpL0FwcExheW91dC5qc3gifQ==