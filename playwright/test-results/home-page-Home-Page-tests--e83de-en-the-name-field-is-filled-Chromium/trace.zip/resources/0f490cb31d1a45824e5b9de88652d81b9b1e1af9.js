import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/cart/DeleteItem.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/DeleteItem.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useDispatch } from "/node_modules/.vite/deps/react-redux.js?v=9f68b94c";
import Button from "/src/ui/Button.jsx";
import { deleteItem } from "/src/features/cart/cartSlice.js";
function DeleteItem({
  pizzaId
}) {
  _s();
  const dispatch = useDispatch();
  return /* @__PURE__ */ jsxDEV(Button, { type: "small", onClick: () => dispatch(deleteItem(pizzaId)), children: "Delete" }, void 0, false, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/DeleteItem.jsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
}
_s(DeleteItem, "rgTLoBID190wEKCp9+G8W6F7A5M=", false, function() {
  return [useDispatch];
});
_c = DeleteItem;
export default DeleteItem;
var _c;
$RefreshReg$(_c, "DeleteItem");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/cart/DeleteItem.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFSSixTQUFTQSxtQkFBbUI7QUFDNUIsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxrQkFBa0I7QUFFM0IsU0FBU0MsV0FBVztBQUFBLEVBQUVDO0FBQVEsR0FBRztBQUFBQyxLQUFBO0FBQy9CLFFBQU1DLFdBQVdOLFlBQVk7QUFFN0IsU0FDRSx1QkFBQyxVQUFPLE1BQUssU0FBUSxTQUFTLE1BQU1NLFNBQVNKLFdBQVdFLE9BQU8sQ0FBQyxHQUFFLHNCQUFsRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDQyxHQVJRRixZQUFVO0FBQUEsVUFDQUgsV0FBVztBQUFBO0FBQUFPLEtBRHJCSjtBQVVULGVBQWVBO0FBQVcsSUFBQUk7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZURpc3BhdGNoIiwiQnV0dG9uIiwiZGVsZXRlSXRlbSIsIkRlbGV0ZUl0ZW0iLCJwaXp6YUlkIiwiX3MiLCJkaXNwYXRjaCIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiRGVsZXRlSXRlbS5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlRGlzcGF0Y2ggfSBmcm9tICdyZWFjdC1yZWR1eCc7XG5pbXBvcnQgQnV0dG9uIGZyb20gJy4uLy4uL3VpL0J1dHRvbic7XG5pbXBvcnQgeyBkZWxldGVJdGVtIH0gZnJvbSAnLi9jYXJ0U2xpY2UnO1xuXG5mdW5jdGlvbiBEZWxldGVJdGVtKHsgcGl6emFJZCB9KSB7XG4gIGNvbnN0IGRpc3BhdGNoID0gdXNlRGlzcGF0Y2goKTtcblxuICByZXR1cm4gKFxuICAgIDxCdXR0b24gdHlwZT1cInNtYWxsXCIgb25DbGljaz17KCkgPT4gZGlzcGF0Y2goZGVsZXRlSXRlbShwaXp6YUlkKSl9PlxuICAgICAgRGVsZXRlXG4gICAgPC9CdXR0b24+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IERlbGV0ZUl0ZW07XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jdXN0b2NhbC9Eb2N1bWVudHMvRGV2ZWxvcG1lbnQvRmFzdC1QaXp6YS1SZWFjdC1JbnRlZ3JhdGlvbi1UZXN0cy9zcmMvZmVhdHVyZXMvY2FydC9EZWxldGVJdGVtLmpzeCJ9