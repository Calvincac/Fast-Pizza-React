import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/Error.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Error.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useRouteError } from "/node_modules/.vite/deps/react-router-dom.js?v=9f68b94c";
import LinkButton from "/src/ui/LinkButton.jsx";
function Error() {
  _s();
  const error = useRouteError();
  console.log(error);
  return /* @__PURE__ */ jsxDEV("div", { "data-auto-id": "error-section", children: [
    /* @__PURE__ */ jsxDEV("h1", { "data-auto-id": "general-error", children: "Something went wrong 😢" }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Error.jsx",
      lineNumber: 9,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { "data-auto-id": "error-message", children: error.data || error.message }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Error.jsx",
      lineNumber: 10,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(LinkButton, { to: "-1", children: "← Go back" }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Error.jsx",
      lineNumber: 12,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Error.jsx",
    lineNumber: 8,
    columnNumber: 10
  }, this);
}
_s(Error, "oAgjgbJzsRXlB89+MoVumxMQqKM=", false, function() {
  return [useRouteError];
});
_c = Error;
export default Error;
var _c;
$RefreshReg$(_c, "Error");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Error.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU007Ozs7Ozs7Ozs7Ozs7Ozs7QUFUTixTQUFTQSxxQkFBcUI7QUFDOUIsT0FBT0MsZ0JBQWdCO0FBRXZCLFNBQVNDLFFBQVE7QUFBQUMsS0FBQTtBQUNmLFFBQU1DLFFBQVFKLGNBQWM7QUFDNUJLLFVBQVFDLElBQUlGLEtBQUs7QUFFakIsU0FDRSx1QkFBQyxTQUFJLGdCQUFhLGlCQUNoQjtBQUFBLDJCQUFDLFFBQUcsZ0JBQWEsaUJBQWdCLHVDQUFqQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQXdEO0FBQUEsSUFDeEQsdUJBQUMsT0FBRSxnQkFBYSxpQkFBaUJBLGdCQUFNRyxRQUFRSCxNQUFNSSxXQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTZEO0FBQUEsSUFFN0QsdUJBQUMsY0FBWSxJQUFHLE1BQUsseUJBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBbUM7QUFBQSxPQUpyQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFFSjtBQUFDTCxHQVpRRCxPQUFLO0FBQUEsVUFDRUYsYUFBYTtBQUFBO0FBQUFTLEtBRHBCUDtBQWNULGVBQWVBO0FBQU0sSUFBQU87QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVJvdXRlRXJyb3IiLCJMaW5rQnV0dG9uIiwiRXJyb3IiLCJfcyIsImVycm9yIiwiY29uc29sZSIsImxvZyIsImRhdGEiLCJtZXNzYWdlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJFcnJvci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlUm91dGVFcnJvciB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuaW1wb3J0IExpbmtCdXR0b24gZnJvbSAnLi9MaW5rQnV0dG9uJztcblxuZnVuY3Rpb24gRXJyb3IoKSB7XG4gIGNvbnN0IGVycm9yID0gdXNlUm91dGVFcnJvcigpO1xuICBjb25zb2xlLmxvZyhlcnJvcik7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGRhdGEtYXV0by1pZD1cImVycm9yLXNlY3Rpb25cIj5cbiAgICAgIDxoMSBkYXRhLWF1dG8taWQ9XCJnZW5lcmFsLWVycm9yXCI+U29tZXRoaW5nIHdlbnQgd3Jvbmcg8J+YojwvaDE+XG4gICAgICA8cCBkYXRhLWF1dG8taWQ9XCJlcnJvci1tZXNzYWdlXCI+e2Vycm9yLmRhdGEgfHwgZXJyb3IubWVzc2FnZX08L3A+XG5cbiAgICAgIDxMaW5rQnV0dG9uICB0bz1cIi0xXCI+JmxhcnI7IEdvIGJhY2s8L0xpbmtCdXR0b24+XG4gICAgPC9kaXY+XG4gICk7XG59XG5cbmV4cG9ydCBkZWZhdWx0IEVycm9yO1xuIl0sImZpbGUiOiIvVXNlcnMvY3VzdG9jYWwvRG9jdW1lbnRzL0RldmVsb3BtZW50L0Zhc3QtUGl6emEtUmVhY3QtSW50ZWdyYXRpb24tVGVzdHMvc3JjL3VpL0Vycm9yLmpzeCJ9