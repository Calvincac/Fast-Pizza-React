import {
  require_react
} from "/node_modules/.vite/deps/chunk-ZVMIEU5R.js?v=9f68b94c";
import "/node_modules/.vite/deps/chunk-UXIASGQL.js?v=9f68b94c";
export default require_react();
//# sourceMappingURL=react.js.map
