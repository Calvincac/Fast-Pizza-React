import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/order/UpdateOrder.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/UpdateOrder.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useFetcher } from "/node_modules/.vite/deps/react-router-dom.js?v=9f68b94c";
import Button from "/src/ui/Button.jsx";
import { updateOrder } from "/src/services/apiRestaurant.js";
function UpdateOrder({
  order
}) {
  _s();
  const fetcher = useFetcher();
  return /* @__PURE__ */ jsxDEV(fetcher.Form, { method: "PATCH", className: "text-right", children: /* @__PURE__ */ jsxDEV(Button, { type: "primary", children: "Make priority" }, void 0, false, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/UpdateOrder.jsx",
    lineNumber: 11,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/UpdateOrder.jsx",
    lineNumber: 10,
    columnNumber: 10
  }, this);
}
_s(UpdateOrder, "2WHaGQTcUOgkXDaibwUgjUp1MBY=", false, function() {
  return [useFetcher];
});
_c = UpdateOrder;
export default UpdateOrder;
export async function action({
  request,
  params
}) {
  const data = {
    priority: true
  };
  await updateOrder(params.orderId, data);
  return null;
}
var _c;
$RefreshReg$(_c, "UpdateOrder");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/UpdateOrder.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU007Ozs7Ozs7Ozs7Ozs7Ozs7QUFUTixTQUFTQSxrQkFBa0I7QUFDM0IsT0FBT0MsWUFBWTtBQUNuQixTQUFTQyxtQkFBbUI7QUFFNUIsU0FBU0MsWUFBWTtBQUFBLEVBQUVDO0FBQU0sR0FBRztBQUFBQyxLQUFBO0FBQzlCLFFBQU1DLFVBQVVOLFdBQVc7QUFFM0IsU0FDRSx1QkFBQyxRQUFRLE1BQVIsRUFBYSxRQUFPLFNBQVEsV0FBVSxjQUNyQyxpQ0FBQyxVQUFPLE1BQUssV0FBVSw2QkFBdkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUFvQyxLQUR0QztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDSyxHQVJRRixhQUFXO0FBQUEsVUFDRkgsVUFBVTtBQUFBO0FBQUFPLEtBRG5CSjtBQVVULGVBQWVBO0FBRWYsc0JBQXNCSyxPQUFPO0FBQUEsRUFBRUM7QUFBQUEsRUFBU0M7QUFBTyxHQUFHO0FBQ2hELFFBQU1DLE9BQU87QUFBQSxJQUFFQyxVQUFVO0FBQUEsRUFBSztBQUM5QixRQUFNVixZQUFZUSxPQUFPRyxTQUFTRixJQUFJO0FBQ3RDLFNBQU87QUFDVDtBQUFDLElBQUFKO0FBQUFPLGFBQUFQLElBQUEiLCJuYW1lcyI6WyJ1c2VGZXRjaGVyIiwiQnV0dG9uIiwidXBkYXRlT3JkZXIiLCJVcGRhdGVPcmRlciIsIm9yZGVyIiwiX3MiLCJmZXRjaGVyIiwiX2MiLCJhY3Rpb24iLCJyZXF1ZXN0IiwicGFyYW1zIiwiZGF0YSIsInByaW9yaXR5Iiwib3JkZXJJZCIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlVwZGF0ZU9yZGVyLmpzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VGZXRjaGVyIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5pbXBvcnQgQnV0dG9uIGZyb20gJy4uLy4uL3VpL0J1dHRvbic7XG5pbXBvcnQgeyB1cGRhdGVPcmRlciB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL2FwaVJlc3RhdXJhbnQnO1xuXG5mdW5jdGlvbiBVcGRhdGVPcmRlcih7IG9yZGVyIH0pIHtcbiAgY29uc3QgZmV0Y2hlciA9IHVzZUZldGNoZXIoKTtcblxuICByZXR1cm4gKFxuICAgIDxmZXRjaGVyLkZvcm0gbWV0aG9kPVwiUEFUQ0hcIiBjbGFzc05hbWU9XCJ0ZXh0LXJpZ2h0XCI+XG4gICAgICA8QnV0dG9uIHR5cGU9XCJwcmltYXJ5XCI+TWFrZSBwcmlvcml0eTwvQnV0dG9uPlxuICAgIDwvZmV0Y2hlci5Gb3JtPlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBVcGRhdGVPcmRlcjtcblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFjdGlvbih7IHJlcXVlc3QsIHBhcmFtcyB9KSB7XG4gIGNvbnN0IGRhdGEgPSB7IHByaW9yaXR5OiB0cnVlIH07XG4gIGF3YWl0IHVwZGF0ZU9yZGVyKHBhcmFtcy5vcmRlcklkLCBkYXRhKTtcbiAgcmV0dXJuIG51bGw7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jdXN0b2NhbC9Eb2N1bWVudHMvRGV2ZWxvcG1lbnQvRmFzdC1QaXp6YS1SZWFjdC1JbnRlZ3JhdGlvbi1UZXN0cy9zcmMvZmVhdHVyZXMvb3JkZXIvVXBkYXRlT3JkZXIuanN4In0=