import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/ui/Button.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Button.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import { Link } from "/node_modules/.vite/deps/react-router-dom.js?v=9f68b94c";
function Button({
  children,
  disabled,
  to,
  type,
  onClick
}) {
  const base = "inline-block text-sm rounded-full bg-yellow-400 font-semibold uppercase tracking-wide text-stone-800 transition-colors duration-300 hover:bg-yellow-300 focus:bg-yellow-300 focus:outline-none focus:ring focus:ring-yellow-300 focus:ring-offset-2 disabled:cursor-not-allowed";
  const styles = {
    primary: base + " px-4 py-3 md:px-6 md:py-4",
    small: base + " px-4 py-2 md:px-5 md:py-2.5 text-xs",
    round: base + " px-2.5 py-1 md:px-3.5 md:py-2 text-sm",
    secondary: "inline-block text-sm rounded-full border-2 border-stone-300 font-semibold uppercase tracking-wide text-stone-400 transition-colors duration-300 hover:bg-stone-300 hover:text-stone-800 focus:bg-stone-300 focus:text-stone-800 focus:outline-none focus:ring focus:ring-stone-200 focus:ring-offset-2 disabled:cursor-not-allowed px-4 py-2.5 md:px-6 md:py-3.5"
  };
  if (to)
    return /* @__PURE__ */ jsxDEV(Link, { to, className: styles[type], children }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Button.jsx",
      lineNumber: 16,
      columnNumber: 18
    }, this);
  if (onClick)
    return /* @__PURE__ */ jsxDEV("button", { onClick, disabled, className: styles[type], children }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Button.jsx",
      lineNumber: 19,
      columnNumber: 23
    }, this);
  return /* @__PURE__ */ jsxDEV("button", { disabled, className: styles[type], children }, void 0, false, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Button.jsx",
    lineNumber: 22,
    columnNumber: 10
  }, this);
}
_c = Button;
export default Button;
var _c;
$RefreshReg$(_c, "Button");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/ui/Button.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JNO0FBaEJOLDJCQUFxQjtBQUFrQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRXZDLFNBQVNBLE9BQU87QUFBQSxFQUFFQztBQUFBQSxFQUFVQztBQUFBQSxFQUFVQztBQUFBQSxFQUFJQztBQUFBQSxFQUFNQztBQUFRLEdBQUc7QUFDekQsUUFBTUMsT0FDSjtBQUVGLFFBQU1DLFNBQVM7QUFBQSxJQUNiQyxTQUFTRixPQUFPO0FBQUEsSUFDaEJHLE9BQU9ILE9BQU87QUFBQSxJQUNkSSxPQUFPSixPQUFPO0FBQUEsSUFDZEssV0FDRTtBQUFBLEVBQ0o7QUFFQSxNQUFJUjtBQUNGLFdBQ0UsdUJBQUMsUUFBSyxJQUFRLFdBQVdJLE9BQU9ILElBQUksR0FDakNILFlBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBR0osTUFBSUk7QUFDRixXQUNFLHVCQUFDLFlBQU8sU0FBa0IsVUFBb0IsV0FBV0UsT0FBT0gsSUFBSSxHQUNqRUgsWUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFHSixTQUNFLHVCQUFDLFlBQU8sVUFBb0IsV0FBV00sT0FBT0gsSUFBSSxHQUMvQ0gsWUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBRUE7QUFFSjtBQUFDVyxLQS9CUVo7QUFpQ1QsZUFBZUE7QUFBTyxJQUFBWTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQnV0dG9uIiwiY2hpbGRyZW4iLCJkaXNhYmxlZCIsInRvIiwidHlwZSIsIm9uQ2xpY2siLCJiYXNlIiwic3R5bGVzIiwicHJpbWFyeSIsInNtYWxsIiwicm91bmQiLCJzZWNvbmRhcnkiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkJ1dHRvbi5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTGluayB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuXG5mdW5jdGlvbiBCdXR0b24oeyBjaGlsZHJlbiwgZGlzYWJsZWQsIHRvLCB0eXBlLCBvbkNsaWNrIH0pIHtcbiAgY29uc3QgYmFzZSA9XG4gICAgJ2lubGluZS1ibG9jayB0ZXh0LXNtIHJvdW5kZWQtZnVsbCBiZy15ZWxsb3ctNDAwIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1zdG9uZS04MDAgdHJhbnNpdGlvbi1jb2xvcnMgZHVyYXRpb24tMzAwIGhvdmVyOmJnLXllbGxvdy0zMDAgZm9jdXM6YmcteWVsbG93LTMwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZyBmb2N1czpyaW5nLXllbGxvdy0zMDAgZm9jdXM6cmluZy1vZmZzZXQtMiBkaXNhYmxlZDpjdXJzb3Itbm90LWFsbG93ZWQnO1xuXG4gIGNvbnN0IHN0eWxlcyA9IHtcbiAgICBwcmltYXJ5OiBiYXNlICsgJyBweC00IHB5LTMgbWQ6cHgtNiBtZDpweS00JyxcbiAgICBzbWFsbDogYmFzZSArICcgcHgtNCBweS0yIG1kOnB4LTUgbWQ6cHktMi41IHRleHQteHMnLFxuICAgIHJvdW5kOiBiYXNlICsgJyBweC0yLjUgcHktMSBtZDpweC0zLjUgbWQ6cHktMiB0ZXh0LXNtJyxcbiAgICBzZWNvbmRhcnk6XG4gICAgICAnaW5saW5lLWJsb2NrIHRleHQtc20gcm91bmRlZC1mdWxsIGJvcmRlci0yIGJvcmRlci1zdG9uZS0zMDAgZm9udC1zZW1pYm9sZCB1cHBlcmNhc2UgdHJhY2tpbmctd2lkZSB0ZXh0LXN0b25lLTQwMCB0cmFuc2l0aW9uLWNvbG9ycyBkdXJhdGlvbi0zMDAgaG92ZXI6Ymctc3RvbmUtMzAwIGhvdmVyOnRleHQtc3RvbmUtODAwIGZvY3VzOmJnLXN0b25lLTMwMCBmb2N1czp0ZXh0LXN0b25lLTgwMCBmb2N1czpvdXRsaW5lLW5vbmUgZm9jdXM6cmluZyBmb2N1czpyaW5nLXN0b25lLTIwMCBmb2N1czpyaW5nLW9mZnNldC0yIGRpc2FibGVkOmN1cnNvci1ub3QtYWxsb3dlZCBweC00IHB5LTIuNSBtZDpweC02IG1kOnB5LTMuNScsXG4gIH07XG5cbiAgaWYgKHRvKVxuICAgIHJldHVybiAoXG4gICAgICA8TGluayB0bz17dG99IGNsYXNzTmFtZT17c3R5bGVzW3R5cGVdfT5cbiAgICAgICAge2NoaWxkcmVufVxuICAgICAgPC9MaW5rPlxuICAgICk7XG5cbiAgaWYgKG9uQ2xpY2spXG4gICAgcmV0dXJuIChcbiAgICAgIDxidXR0b24gb25DbGljaz17b25DbGlja30gZGlzYWJsZWQ9e2Rpc2FibGVkfSBjbGFzc05hbWU9e3N0eWxlc1t0eXBlXX0+XG4gICAgICAgIHtjaGlsZHJlbn1cbiAgICAgIDwvYnV0dG9uPlxuICAgICk7XG5cbiAgcmV0dXJuIChcbiAgICA8YnV0dG9uIGRpc2FibGVkPXtkaXNhYmxlZH0gY2xhc3NOYW1lPXtzdHlsZXNbdHlwZV19PlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvYnV0dG9uPlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBCdXR0b247XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jdXN0b2NhbC9Eb2N1bWVudHMvRGV2ZWxvcG1lbnQvRmFzdC1QaXp6YS1SZWFjdC1JbnRlZ3JhdGlvbi1UZXN0cy9zcmMvdWkvQnV0dG9uLmpzeCJ9