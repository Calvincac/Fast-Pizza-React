import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/order/SearchOrder.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/SearchOrder.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=9f68b94c"; const useState = __vite__cjsImport3_react["useState"];
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=9f68b94c";
function SearchOrder() {
  _s();
  const [query, setQuery] = useState("");
  const navigate = useNavigate();
  function handleSubmit(e) {
    e.preventDefault();
    if (!query)
      return;
    navigate(`/order/${query}`);
    setQuery("");
  }
  return /* @__PURE__ */ jsxDEV("form", { onSubmit: handleSubmit, children: /* @__PURE__ */ jsxDEV("input", { "data-auto-id": "search-order", placeholder: "Search order #", value: query, onChange: (e) => setQuery(e.target.value), className: "w-28 rounded-full bg-yellow-100 px-4 py-2 text-sm transition-all duration-300 placeholder:text-stone-400 focus:outline-none focus:ring focus:ring-yellow-500 focus:ring-opacity-50 sm:w-64 sm:focus:w-72" }, void 0, false, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/SearchOrder.jsx",
    lineNumber: 15,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/SearchOrder.jsx",
    lineNumber: 14,
    columnNumber: 10
  }, this);
}
_s(SearchOrder, "4dav8M2SLGXQnIi3dGQyN/4cmLs=", false, function() {
  return [useNavigate];
});
_c = SearchOrder;
export default SearchOrder;
var _c;
$RefreshReg$(_c, "SearchOrder");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/SearchOrder.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JNOzs7Ozs7Ozs7Ozs7Ozs7O0FBaEJOLFNBQVNBLGdCQUFnQjtBQUN6QixTQUFTQyxtQkFBbUI7QUFFNUIsU0FBU0MsY0FBYztBQUFBQyxLQUFBO0FBQ3JCLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJTCxTQUFTLEVBQUU7QUFDckMsUUFBTU0sV0FBV0wsWUFBWTtBQUU3QixXQUFTTSxhQUFhQyxHQUFHO0FBQ3ZCQSxNQUFFQyxlQUFlO0FBQ2pCLFFBQUksQ0FBQ0w7QUFBTztBQUNaRSxhQUFVLFVBQVNGLEtBQU0sRUFBQztBQUMxQkMsYUFBUyxFQUFFO0FBQUEsRUFDYjtBQUVBLFNBQ0UsdUJBQUMsVUFBSyxVQUFVRSxjQUNkLGlDQUFDLFdBQ0MsZ0JBQWEsZ0JBQ2IsYUFBWSxrQkFDWixPQUFPSCxPQUNQLFVBQVdJLE9BQU1ILFNBQVNHLEVBQUVFLE9BQU9DLEtBQUssR0FDeEMsV0FBVSw4TUFMWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS3NOLEtBTnhOO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRQTtBQUVKO0FBQUNSLEdBdEJRRCxhQUFXO0FBQUEsVUFFREQsV0FBVztBQUFBO0FBQUFXLEtBRnJCVjtBQXdCVCxlQUFlQTtBQUFZLElBQUFVO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZU5hdmlnYXRlIiwiU2VhcmNoT3JkZXIiLCJfcyIsInF1ZXJ5Iiwic2V0UXVlcnkiLCJuYXZpZ2F0ZSIsImhhbmRsZVN1Ym1pdCIsImUiLCJwcmV2ZW50RGVmYXVsdCIsInRhcmdldCIsInZhbHVlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTZWFyY2hPcmRlci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nO1xuXG5mdW5jdGlvbiBTZWFyY2hPcmRlcigpIHtcbiAgY29uc3QgW3F1ZXJ5LCBzZXRRdWVyeV0gPSB1c2VTdGF0ZSgnJyk7XG4gIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKTtcblxuICBmdW5jdGlvbiBoYW5kbGVTdWJtaXQoZSkge1xuICAgIGUucHJldmVudERlZmF1bHQoKTtcbiAgICBpZiAoIXF1ZXJ5KSByZXR1cm47XG4gICAgbmF2aWdhdGUoYC9vcmRlci8ke3F1ZXJ5fWApO1xuICAgIHNldFF1ZXJ5KCcnKTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGZvcm0gb25TdWJtaXQ9e2hhbmRsZVN1Ym1pdH0+XG4gICAgICA8aW5wdXRcbiAgICAgICAgZGF0YS1hdXRvLWlkPVwic2VhcmNoLW9yZGVyXCJcbiAgICAgICAgcGxhY2Vob2xkZXI9XCJTZWFyY2ggb3JkZXIgI1wiXG4gICAgICAgIHZhbHVlPXtxdWVyeX1cbiAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBzZXRRdWVyeShlLnRhcmdldC52YWx1ZSl9XG4gICAgICAgIGNsYXNzTmFtZT1cInctMjggcm91bmRlZC1mdWxsIGJnLXllbGxvdy0xMDAgcHgtNCBweS0yIHRleHQtc20gdHJhbnNpdGlvbi1hbGwgZHVyYXRpb24tMzAwIHBsYWNlaG9sZGVyOnRleHQtc3RvbmUtNDAwIGZvY3VzOm91dGxpbmUtbm9uZSBmb2N1czpyaW5nIGZvY3VzOnJpbmcteWVsbG93LTUwMCBmb2N1czpyaW5nLW9wYWNpdHktNTAgc206dy02NCBzbTpmb2N1czp3LTcyXCJcbiAgICAgIC8+XG4gICAgPC9mb3JtPlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBTZWFyY2hPcmRlcjtcbiJdLCJmaWxlIjoiL1VzZXJzL2N1c3RvY2FsL0RvY3VtZW50cy9EZXZlbG9wbWVudC9GYXN0LVBpenphLVJlYWN0LUludGVncmF0aW9uLVRlc3RzL3NyYy9mZWF0dXJlcy9vcmRlci9TZWFyY2hPcmRlci5qc3gifQ==