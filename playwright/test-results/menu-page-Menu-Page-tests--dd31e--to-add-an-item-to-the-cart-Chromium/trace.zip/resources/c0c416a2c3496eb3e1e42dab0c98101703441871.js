import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/order/Order.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useFetcher, useLoaderData } from "/node_modules/.vite/deps/react-router-dom.js?v=9f68b94c";
import OrderItem from "/src/features/order/OrderItem.jsx";
import { getOrder } from "/src/services/apiRestaurant.js";
import { calcMinutesLeft, formatCurrency, formatDate } from "/src/utils/helpers.js";
import __vite__cjsImport7_react from "/node_modules/.vite/deps/react.js?v=9f68b94c"; const useEffect = __vite__cjsImport7_react["useEffect"];
import UpdateOrder from "/src/features/order/UpdateOrder.jsx";
function Order() {
  _s();
  const order = useLoaderData();
  const fetcher = useFetcher();
  useEffect(function() {
    if (!fetcher.data && fetcher.state === "idle")
      fetcher.load("/menu");
  }, [fetcher]);
  const {
    id,
    status,
    priority,
    priorityPrice,
    orderPrice,
    estimatedDelivery,
    cart
  } = order;
  const deliveryIn = calcMinutesLeft(estimatedDelivery);
  return /* @__PURE__ */ jsxDEV("div", { className: "space-y-8 px-4 py-6", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-2", children: [
      /* @__PURE__ */ jsxDEV("h2", { "data-auto-id": "order-id", className: "text-xl font-semibold", children: [
        "Order #",
        id,
        " status"
      ] }, void 0, true, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx",
        lineNumber: 30,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "space-x-2", children: [
        priority && /* @__PURE__ */ jsxDEV("span", { "data-auto-id": "priority-label", className: "rounded-full bg-red-500 px-3 py-1 text-sm font-semibold uppercase tracking-wide text-red-50", children: "Priority" }, void 0, false, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx",
          lineNumber: 33,
          columnNumber: 24
        }, this),
        /* @__PURE__ */ jsxDEV("span", { "data-auto-id": "order-status", className: "rounded-full bg-green-500 px-3 py-1 text-sm font-semibold uppercase tracking-wide text-green-50", children: [
          status,
          " order"
        ] }, void 0, true, {
          fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx",
          lineNumber: 36,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx",
        lineNumber: 32,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx",
      lineNumber: 29,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap items-center justify-between gap-2 bg-stone-200 px-6 py-5", children: [
      /* @__PURE__ */ jsxDEV("p", { "data-auto-id": "order-eta", className: "font-medium", children: deliveryIn >= 0 ? `Only ${calcMinutesLeft(estimatedDelivery)} minutes left 😃` : "Order should have arrived" }, void 0, false, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx",
        lineNumber: 43,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-stone-500", children: [
        "(Estimated delivery: ",
        formatDate(estimatedDelivery),
        ")"
      ] }, void 0, true, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx",
        lineNumber: 46,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx",
      lineNumber: 42,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("ul", { className: "dive-stone-200 divide-y border-b border-t", children: cart.map((item) => /* @__PURE__ */ jsxDEV(OrderItem, { item, isLoadingIngredients: fetcher.state === "loading", ingredients: fetcher?.data?.find((el) => el.id === item.pizzaId)?.ingredients ?? [] }, item.pizzaId, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx",
      lineNumber: 52,
      columnNumber: 27
    }, this)) }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx",
      lineNumber: 51,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("div", { className: "space-y-2 bg-stone-200 px-6 py-5", children: [
      /* @__PURE__ */ jsxDEV("p", { "data-auto-id": "pizza-price", className: "text-sm font-medium text-stone-600", children: [
        "Price pizza: ",
        formatCurrency(orderPrice)
      ] }, void 0, true, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx",
        lineNumber: 56,
        columnNumber: 9
      }, this),
      priority && /* @__PURE__ */ jsxDEV("p", { "data-auto-id": "priority-price", className: "text-sm font-medium text-stone-600", children: [
        "Price priority: ",
        formatCurrency(priorityPrice)
      ] }, void 0, true, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx",
        lineNumber: 59,
        columnNumber: 22
      }, this),
      /* @__PURE__ */ jsxDEV("p", { "data-auto-id": "total-order-price", className: "font-bold", children: [
        "To pay on delivery: ",
        formatCurrency(orderPrice + priorityPrice)
      ] }, void 0, true, {
        fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx",
        lineNumber: 62,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx",
      lineNumber: 55,
      columnNumber: 7
    }, this),
    !priority && /* @__PURE__ */ jsxDEV(UpdateOrder, { order }, void 0, false, {
      fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx",
      lineNumber: 67,
      columnNumber: 21
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx",
    lineNumber: 28,
    columnNumber: 10
  }, this);
}
_s(Order, "dtRrVEGZ3CILVA1VGhjIrPLRpqg=", false, function() {
  return [useLoaderData, useFetcher];
});
_c = Order;
export async function loader({
  params
}) {
  const order = await getOrder(params.orderId);
  return order;
}
export default Order;
var _c;
$RefreshReg$(_c, "Order");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/order/Order.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUNROzs7Ozs7Ozs7Ozs7Ozs7O0FBeENSLFNBQVNBLFlBQVlDLHFCQUFxQjtBQUUxQyxPQUFPQyxlQUFlO0FBRXRCLFNBQVNDLGdCQUFnQjtBQUN6QixTQUNFQyxpQkFDQUMsZ0JBQ0FDLGtCQUNLO0FBQ1AsU0FBU0MsaUJBQWlCO0FBQzFCLE9BQU9DLGlCQUFpQjtBQUV4QixTQUFTQyxRQUFRO0FBQUFDLEtBQUE7QUFDZixRQUFNQyxRQUFRVixjQUFjO0FBQzVCLFFBQU1XLFVBQVVaLFdBQVc7QUFFM0JPLFlBQ0UsV0FBWTtBQUNWLFFBQUksQ0FBQ0ssUUFBUUMsUUFBUUQsUUFBUUUsVUFBVTtBQUFRRixjQUFRRyxLQUFLLE9BQU87QUFBQSxFQUNyRSxHQUNBLENBQUNILE9BQU8sQ0FDVjtBQUdBLFFBQU07QUFBQSxJQUNKSTtBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxJQUNBQztBQUFBQSxFQUNGLElBQUlYO0FBRUosUUFBTVksYUFBYW5CLGdCQUFnQmlCLGlCQUFpQjtBQUVwRCxTQUNFLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLDJCQUFDLFNBQUksV0FBVSxxREFDYjtBQUFBLDZCQUFDLFFBQUcsZ0JBQWEsWUFBVyxXQUFVLHlCQUF3QjtBQUFBO0FBQUEsUUFBUUw7QUFBQUEsUUFBRztBQUFBLFdBQXpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBZ0Y7QUFBQSxNQUVoRix1QkFBQyxTQUFJLFdBQVUsYUFDWkU7QUFBQUEsb0JBQ0MsdUJBQUMsVUFBSyxnQkFBYSxrQkFBaUIsV0FBVSwrRkFBNkYsd0JBQTNJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBRUYsdUJBQUMsVUFBSyxnQkFBYSxnQkFBZSxXQUFVLG1HQUN6Q0Q7QUFBQUE7QUFBQUEsVUFBTztBQUFBLGFBRFY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsV0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBU0E7QUFBQSxTQVpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FhQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLDRFQUNiO0FBQUEsNkJBQUMsT0FBRSxnQkFBYSxhQUFZLFdBQVUsZUFDbkNNLHdCQUFjLElBQ1YsUUFBT25CLGdCQUFnQmlCLGlCQUFpQixDQUFFLHFCQUMzQywrQkFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBSUE7QUFBQSxNQUNBLHVCQUFDLE9BQUUsV0FBVSwwQkFBd0I7QUFBQTtBQUFBLFFBQ2JmLFdBQVdlLGlCQUFpQjtBQUFBLFFBQUU7QUFBQSxXQUR0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxTQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FTQTtBQUFBLElBRUEsdUJBQUMsUUFBRyxXQUFVLDZDQUNYQyxlQUFLRSxJQUFLQyxVQUNULHVCQUFDLGFBQ0MsTUFFQSxzQkFBc0JiLFFBQVFFLFVBQVUsV0FDeEMsYUFDRUYsU0FBU0MsTUFBTWEsS0FBTUMsUUFBT0EsR0FBR1gsT0FBT1MsS0FBS0csT0FBTyxHQUM5Q0MsZUFBZSxNQUpoQkosS0FBS0csU0FGWjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0csQ0FFSixLQVhIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FZQTtBQUFBLElBRUEsdUJBQUMsU0FBSSxXQUFVLG9DQUNiO0FBQUEsNkJBQUMsT0FBRSxnQkFBYSxlQUFjLFdBQVUsc0NBQW9DO0FBQUE7QUFBQSxRQUM1RHZCLGVBQWVlLFVBQVU7QUFBQSxXQUR6QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBRUE7QUFBQSxNQUNDRixZQUNDLHVCQUFDLE9BQUUsZ0JBQWEsa0JBQWlCLFdBQVUsc0NBQW9DO0FBQUE7QUFBQSxRQUM1RGIsZUFBZWMsYUFBYTtBQUFBLFdBRC9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLE1BRUYsdUJBQUMsT0FBRSxnQkFBYSxxQkFBb0IsV0FBVSxhQUFXO0FBQUE7QUFBQSxRQUNsQ2QsZUFBZWUsYUFBYUQsYUFBYTtBQUFBLFdBRGhFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQTtBQUFBLFNBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVlBO0FBQUEsSUFFQyxDQUFDRCxZQUFZLHVCQUFDLGVBQVksU0FBYjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBCO0FBQUEsT0F2RDFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F3REE7QUFFSjtBQUFDUixHQW5GUUQsT0FBSztBQUFBLFVBQ0VSLGVBQ0VELFVBQVU7QUFBQTtBQUFBOEIsS0FGbkJyQjtBQXFGVCxzQkFBc0JzQixPQUFPO0FBQUEsRUFBRUM7QUFBTyxHQUFHO0FBQ3ZDLFFBQU1yQixRQUFRLE1BQU1SLFNBQVM2QixPQUFPQyxPQUFPO0FBQzNDLFNBQU90QjtBQUNUO0FBRUEsZUFBZUY7QUFBTSxJQUFBcUI7QUFBQUksYUFBQUosSUFBQSIsIm5hbWVzIjpbInVzZUZldGNoZXIiLCJ1c2VMb2FkZXJEYXRhIiwiT3JkZXJJdGVtIiwiZ2V0T3JkZXIiLCJjYWxjTWludXRlc0xlZnQiLCJmb3JtYXRDdXJyZW5jeSIsImZvcm1hdERhdGUiLCJ1c2VFZmZlY3QiLCJVcGRhdGVPcmRlciIsIk9yZGVyIiwiX3MiLCJvcmRlciIsImZldGNoZXIiLCJkYXRhIiwic3RhdGUiLCJsb2FkIiwiaWQiLCJzdGF0dXMiLCJwcmlvcml0eSIsInByaW9yaXR5UHJpY2UiLCJvcmRlclByaWNlIiwiZXN0aW1hdGVkRGVsaXZlcnkiLCJjYXJ0IiwiZGVsaXZlcnlJbiIsIm1hcCIsIml0ZW0iLCJmaW5kIiwiZWwiLCJwaXp6YUlkIiwiaW5ncmVkaWVudHMiLCJfYyIsImxvYWRlciIsInBhcmFtcyIsIm9yZGVySWQiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJPcmRlci5qc3giXSwic291cmNlc0NvbnRlbnQiOlsiLy8gVGVzdCBJRDogSUlEU0FUXG5pbXBvcnQgeyB1c2VGZXRjaGVyLCB1c2VMb2FkZXJEYXRhIH0gZnJvbSAncmVhY3Qtcm91dGVyLWRvbSc7XG5cbmltcG9ydCBPcmRlckl0ZW0gZnJvbSAnLi9PcmRlckl0ZW0nO1xuXG5pbXBvcnQgeyBnZXRPcmRlciB9IGZyb20gJy4uLy4uL3NlcnZpY2VzL2FwaVJlc3RhdXJhbnQnO1xuaW1wb3J0IHtcbiAgY2FsY01pbnV0ZXNMZWZ0LFxuICBmb3JtYXRDdXJyZW5jeSxcbiAgZm9ybWF0RGF0ZSxcbn0gZnJvbSAnLi4vLi4vdXRpbHMvaGVscGVycyc7XG5pbXBvcnQgeyB1c2VFZmZlY3QgfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgVXBkYXRlT3JkZXIgZnJvbSAnLi9VcGRhdGVPcmRlcic7XG5cbmZ1bmN0aW9uIE9yZGVyKCkge1xuICBjb25zdCBvcmRlciA9IHVzZUxvYWRlckRhdGEoKTtcbiAgY29uc3QgZmV0Y2hlciA9IHVzZUZldGNoZXIoKTtcblxuICB1c2VFZmZlY3QoXG4gICAgZnVuY3Rpb24gKCkge1xuICAgICAgaWYgKCFmZXRjaGVyLmRhdGEgJiYgZmV0Y2hlci5zdGF0ZSA9PT0gJ2lkbGUnKSBmZXRjaGVyLmxvYWQoJy9tZW51Jyk7XG4gICAgfSxcbiAgICBbZmV0Y2hlcl1cbiAgKTtcblxuICAvLyBFdmVyeW9uZSBjYW4gc2VhcmNoIGZvciBhbGwgb3JkZXJzLCBzbyBmb3IgcHJpdmFjeSByZWFzb25zIHdlJ3JlIGdvbm5hIGdvbm5hIGV4Y2x1ZGUgbmFtZXMgb3IgYWRkcmVzcywgdGhlc2UgYXJlIG9ubHkgZm9yIHRoZSByZXN0YXVyYW50IHN0YWZmXG4gIGNvbnN0IHtcbiAgICBpZCxcbiAgICBzdGF0dXMsXG4gICAgcHJpb3JpdHksXG4gICAgcHJpb3JpdHlQcmljZSxcbiAgICBvcmRlclByaWNlLFxuICAgIGVzdGltYXRlZERlbGl2ZXJ5LFxuICAgIGNhcnQsXG4gIH0gPSBvcmRlcjtcblxuICBjb25zdCBkZWxpdmVyeUluID0gY2FsY01pbnV0ZXNMZWZ0KGVzdGltYXRlZERlbGl2ZXJ5KTtcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwic3BhY2UteS04IHB4LTQgcHktNlwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtd3JhcCBpdGVtcy1jZW50ZXIganVzdGlmeS1iZXR3ZWVuIGdhcC0yXCI+XG4gICAgICAgIDxoMiBkYXRhLWF1dG8taWQ9XCJvcmRlci1pZFwiIGNsYXNzTmFtZT1cInRleHQteGwgZm9udC1zZW1pYm9sZFwiPk9yZGVyICN7aWR9IHN0YXR1czwvaDI+XG5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS14LTJcIj5cbiAgICAgICAgICB7cHJpb3JpdHkgJiYgKFxuICAgICAgICAgICAgPHNwYW4gZGF0YS1hdXRvLWlkPVwicHJpb3JpdHktbGFiZWxcIiBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctcmVkLTUwMCBweC0zIHB5LTEgdGV4dC1zbSBmb250LXNlbWlib2xkIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtcmVkLTUwXCI+XG4gICAgICAgICAgICAgIFByaW9yaXR5XG4gICAgICAgICAgICA8L3NwYW4+XG4gICAgICAgICAgKX1cbiAgICAgICAgICA8c3BhbiBkYXRhLWF1dG8taWQ9XCJvcmRlci1zdGF0dXNcIiBjbGFzc05hbWU9XCJyb3VuZGVkLWZ1bGwgYmctZ3JlZW4tNTAwIHB4LTMgcHktMSB0ZXh0LXNtIGZvbnQtc2VtaWJvbGQgdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1ncmVlbi01MFwiPlxuICAgICAgICAgICAge3N0YXR1c30gb3JkZXJcbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBmbGV4LXdyYXAgaXRlbXMtY2VudGVyIGp1c3RpZnktYmV0d2VlbiBnYXAtMiBiZy1zdG9uZS0yMDAgcHgtNiBweS01XCI+XG4gICAgICAgIDxwIGRhdGEtYXV0by1pZD1cIm9yZGVyLWV0YVwiIGNsYXNzTmFtZT1cImZvbnQtbWVkaXVtXCI+XG4gICAgICAgICAge2RlbGl2ZXJ5SW4gPj0gMFxuICAgICAgICAgICAgPyBgT25seSAke2NhbGNNaW51dGVzTGVmdChlc3RpbWF0ZWREZWxpdmVyeSl9IG1pbnV0ZXMgbGVmdCDwn5iDYFxuICAgICAgICAgICAgOiAnT3JkZXIgc2hvdWxkIGhhdmUgYXJyaXZlZCd9XG4gICAgICAgIDwvcD5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXN0b25lLTUwMFwiPlxuICAgICAgICAgIChFc3RpbWF0ZWQgZGVsaXZlcnk6IHtmb3JtYXREYXRlKGVzdGltYXRlZERlbGl2ZXJ5KX0pXG4gICAgICAgIDwvcD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8dWwgY2xhc3NOYW1lPVwiZGl2ZS1zdG9uZS0yMDAgZGl2aWRlLXkgYm9yZGVyLWIgYm9yZGVyLXRcIj5cbiAgICAgICAge2NhcnQubWFwKChpdGVtKSA9PiAoXG4gICAgICAgICAgPE9yZGVySXRlbVxuICAgICAgICAgICAgaXRlbT17aXRlbX1cbiAgICAgICAgICAgIGtleT17aXRlbS5waXp6YUlkfVxuICAgICAgICAgICAgaXNMb2FkaW5nSW5ncmVkaWVudHM9e2ZldGNoZXIuc3RhdGUgPT09ICdsb2FkaW5nJ31cbiAgICAgICAgICAgIGluZ3JlZGllbnRzPXtcbiAgICAgICAgICAgICAgZmV0Y2hlcj8uZGF0YT8uZmluZCgoZWwpID0+IGVsLmlkID09PSBpdGVtLnBpenphSWQpXG4gICAgICAgICAgICAgICAgPy5pbmdyZWRpZW50cyA/PyBbXVxuICAgICAgICAgICAgfVxuICAgICAgICAgIC8+XG4gICAgICAgICkpfVxuICAgICAgPC91bD5cblxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzcGFjZS15LTIgYmctc3RvbmUtMjAwIHB4LTYgcHktNVwiPlxuICAgICAgICA8cCBkYXRhLWF1dG8taWQ9XCJwaXp6YS1wcmljZVwiIGNsYXNzTmFtZT1cInRleHQtc20gZm9udC1tZWRpdW0gdGV4dC1zdG9uZS02MDBcIj5cbiAgICAgICAgICBQcmljZSBwaXp6YToge2Zvcm1hdEN1cnJlbmN5KG9yZGVyUHJpY2UpfVxuICAgICAgICA8L3A+XG4gICAgICAgIHtwcmlvcml0eSAmJiAoXG4gICAgICAgICAgPHAgZGF0YS1hdXRvLWlkPVwicHJpb3JpdHktcHJpY2VcIiBjbGFzc05hbWU9XCJ0ZXh0LXNtIGZvbnQtbWVkaXVtIHRleHQtc3RvbmUtNjAwXCI+XG4gICAgICAgICAgICBQcmljZSBwcmlvcml0eToge2Zvcm1hdEN1cnJlbmN5KHByaW9yaXR5UHJpY2UpfVxuICAgICAgICAgIDwvcD5cbiAgICAgICAgKX1cbiAgICAgICAgPHAgZGF0YS1hdXRvLWlkPVwidG90YWwtb3JkZXItcHJpY2VcIiBjbGFzc05hbWU9XCJmb250LWJvbGRcIj5cbiAgICAgICAgICBUbyBwYXkgb24gZGVsaXZlcnk6IHtmb3JtYXRDdXJyZW5jeShvcmRlclByaWNlICsgcHJpb3JpdHlQcmljZSl9XG4gICAgICAgIDwvcD5cbiAgICAgIDwvZGl2PlxuXG4gICAgICB7IXByaW9yaXR5ICYmIDxVcGRhdGVPcmRlciBvcmRlcj17b3JkZXJ9IC8+fVxuICAgIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gbG9hZGVyKHsgcGFyYW1zIH0pIHtcbiAgY29uc3Qgb3JkZXIgPSBhd2FpdCBnZXRPcmRlcihwYXJhbXMub3JkZXJJZCk7XG4gIHJldHVybiBvcmRlcjtcbn1cblxuZXhwb3J0IGRlZmF1bHQgT3JkZXI7XG4iXSwiZmlsZSI6Ii9Vc2Vycy9jdXN0b2NhbC9Eb2N1bWVudHMvRGV2ZWxvcG1lbnQvRmFzdC1QaXp6YS1SZWFjdC1JbnRlZ3JhdGlvbi1UZXN0cy9zcmMvZmVhdHVyZXMvb3JkZXIvT3JkZXIuanN4In0=