import { injectQuery as __vite__injectQuery } from "/@vite/client";import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/features/user/Username.jsx");import { jsxDEV } from "/@id/__x00__react/jsx-dev-runtime";
import RefreshRuntime from "/@react-refresh";
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/user/Username.jsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useSelector } from "/node_modules/.vite/deps/react-redux.js?v=9f68b94c";
function Username() {
  _s();
  const username = useSelector((state) => state.user.username);
  if (!username)
    return null;
  return /* @__PURE__ */ jsxDEV("div", { "data-auto-id": "logged-in-username", className: "hidden text-sm font-semibold md:block", children: username }, void 0, false, {
    fileName: "/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/user/Username.jsx",
    lineNumber: 7,
    columnNumber: 10
  }, this);
}
_s(Username, "Hd4PBq58Xc1y9+EldUXenW1lAB0=", false, function() {
  return [useSelector];
});
_c = Username;
export default Username;
var _c;
$RefreshReg$(_c, "Username");
if (import.meta.hot) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  import(
    /* @vite-ignore */
    __vite__injectQuery(import.meta.url, 'import')).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/custocal/Documents/Development/Fast-Pizza-React-Integration-Tests/src/features/user/Username.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBUUk7Ozs7Ozs7Ozs7Ozs7Ozs7QUFSSixTQUFTQSxtQkFBbUI7QUFFNUIsU0FBU0MsV0FBVztBQUFBQyxLQUFBO0FBQ2xCLFFBQU1DLFdBQVdILFlBQWFJLFdBQVVBLE1BQU1DLEtBQUtGLFFBQVE7QUFFM0QsTUFBSSxDQUFDQTtBQUFVLFdBQU87QUFFdEIsU0FDRSx1QkFBQyxTQUFJLGdCQUFhLHNCQUFxQixXQUFVLHlDQUF5Q0Esc0JBQTFGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FBbUc7QUFFdkc7QUFBQ0QsR0FSUUQsVUFBUTtBQUFBLFVBQ0VELFdBQVc7QUFBQTtBQUFBTSxLQURyQkw7QUFVVCxlQUFlQTtBQUFTLElBQUFLO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTZWxlY3RvciIsIlVzZXJuYW1lIiwiX3MiLCJ1c2VybmFtZSIsInN0YXRlIiwidXNlciIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiVXNlcm5hbWUuanN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVNlbGVjdG9yIH0gZnJvbSAncmVhY3QtcmVkdXgnO1xuXG5mdW5jdGlvbiBVc2VybmFtZSgpIHtcbiAgY29uc3QgdXNlcm5hbWUgPSB1c2VTZWxlY3Rvcigoc3RhdGUpID0+IHN0YXRlLnVzZXIudXNlcm5hbWUpO1xuXG4gIGlmICghdXNlcm5hbWUpIHJldHVybiBudWxsO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBkYXRhLWF1dG8taWQ9XCJsb2dnZWQtaW4tdXNlcm5hbWVcIiBjbGFzc05hbWU9XCJoaWRkZW4gdGV4dC1zbSBmb250LXNlbWlib2xkIG1kOmJsb2NrXCI+e3VzZXJuYW1lfTwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBVc2VybmFtZTtcbiJdLCJmaWxlIjoiL1VzZXJzL2N1c3RvY2FsL0RvY3VtZW50cy9EZXZlbG9wbWVudC9GYXN0LVBpenphLVJlYWN0LUludGVncmF0aW9uLVRlc3RzL3NyYy9mZWF0dXJlcy91c2VyL1VzZXJuYW1lLmpzeCJ9